package com.hoperun.springmvc.web.validator;

import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.hoperun.springmvc.web.controller.UserController;

public class BankAcountValidator implements ConstraintValidator<BankAcount, Double> {

	private String moneyReg = "^\\d+(\\.\\d{2})?$";//表示金额的正则表达式  
    private Pattern moneyPattern = Pattern.compile(moneyReg);  
    /**
     * 这里只是说明，在spring环境下，可以相互依赖
     */
    @Autowired
    private UserController controller;  
    
    private BankAcount money;
     
    
    public BankAcount getMoney() {
		return money;
	}

	public void setMoney(BankAcount money) {
		this.money = money;
	}

	@Override
    public void initialize(BankAcount money) {  
       this.money = money;
        
    }  
    
    @Override
    public boolean isValid(Double value, ConstraintValidatorContext arg1) {  
       if (value == null)  
           return true;  
       return moneyPattern.matcher(value.toString()).matches();  
    }  
   
    public UserController getController() {  
       return controller;  
    }  
   
      
    public void setController(UserController controller) {  
       this.controller = controller;  
    }  
}
