package com.hoperun.springmvc.web.dto;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;

import com.hoperun.springmvc.constant.Gender;
import com.hoperun.springmvc.web.validator.BankAcount;

public class UserDTO {
	
	@NotNull(message="id 不可为空")
	private Long id;
	
	private String name;
	
	private int age;
	
	private Gender gender;
	
	private JobDTO job;
	
	@BankAcount(message="资金账户金额格式不正确")
	private double bankAccount;
	
	public double getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(double bankAccount) {
		this.bankAccount = bankAccount;
	}

	@Email(message="邮件地址无效")
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public JobDTO getJob() {
		return job;
	}

	public void setJob(JobDTO job) {
		this.job = job;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", name=" + name + ", age=" + age
				+ ", gender=" + gender + "]";
	}
	
	
}
