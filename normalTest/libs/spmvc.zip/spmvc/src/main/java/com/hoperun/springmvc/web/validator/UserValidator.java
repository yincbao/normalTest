package com.hoperun.springmvc.web.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.hoperun.springmvc.web.dto.UserDTO;

/**
 * spring mvc第二种valid方式验证：自定义validator。需要在controller里面理由initbinder注解，或者servlet.xml <mvc:annotation-driven validator="userValidator"/> 
 * @author yin_changbao
 *
 */
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return UserDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "user name is null");
		UserDTO user = (UserDTO) target;
		if(user.getAge()<0)
			errors.rejectValue("age", "invalid age", "age should greater than or equal to 0");  
	}

}
