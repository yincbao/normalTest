package com.hoperun.springmvc.web.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hoperun.springmvc.web.dto.UserDTO;
import com.hoperun.springmvc.web.validator.UserValidator;

@Controller
@RequestMapping(value = "/user")
public class UserController {

	@InitBinder//仅controller内有效，想要全局有效，可以在配置文件里面加：<mvc:annotation-driven validator="userValidator"/> 
	public void initBinder(DataBinder binder) {
		binder.setValidator(new UserValidator());
	}

	@RequestMapping(method = RequestMethod.GET)
	public String queryUser(@Valid UserDTO user, Model uiModel, BindingResult br) {
		if (br.hasErrors())
			System.out.println(br);
		user.setAge(100);
		uiModel.addAttribute("user", user);
		return "viewUser";
	}

}
