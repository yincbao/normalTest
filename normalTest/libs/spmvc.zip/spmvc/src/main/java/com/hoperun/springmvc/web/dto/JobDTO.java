package com.hoperun.springmvc.web.dto;

public class JobDTO {
	
	private String jobName;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
	

}
