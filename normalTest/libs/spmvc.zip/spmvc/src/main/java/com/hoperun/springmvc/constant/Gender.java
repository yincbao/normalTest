package com.hoperun.springmvc.constant;

public enum Gender {
	
	male(1),female(2);
	
	private int code;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	private Gender(int code) {
		this.code = code;
	}
	
}
