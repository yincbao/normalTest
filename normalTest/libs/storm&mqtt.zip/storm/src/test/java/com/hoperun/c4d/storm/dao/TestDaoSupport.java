package com.hoperun.c4d.storm.dao;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hoperun.c4d.service.IFileService;
import com.hoperun.c4d.storm.ClinetSimulator;
import com.hoperun.c4d.util.StormUtil;

public class TestDaoSupport {

	private static final Log logger = LogFactory.getLog(ClinetSimulator.class);

	public static ApplicationContext applicationContext = null;
	
	@BeforeClass
	public static void setUpBeforeClass() {
		try{
			applicationContext = new ClassPathXmlApplicationContext(new String[] { "classpath*:/spring-all.xml" });
		}catch(Exception e ){
			logger.error(e.getMessage(), e);
		}
		
	}
	
	@Test
	public void testInsertFile(){
		IFileService fileService = (IFileService) applicationContext.getBean("fileService");
		fileService.saveImg("D:/test/copy_of_device-mgr.img");
		
	}
	
	@Test
	public void testDelFile(){
		IFileService fileService = (IFileService) applicationContext.getBean("fileService");
		fileService.delImg("BsonNull");
		
	}
	
	@Test
	public void testQueryFile(){
		IFileService fileService = (IFileService) applicationContext.getBean("fileService");
		long start = System.currentTimeMillis();
		List<File> files = fileService.queryImg("img","D:/gfsoutput");
		if(!StormUtil.isEmptyCollection(files)){
			for(File file:files){
				if(!file.getParentFile().exists())
					file.getParentFile().mkdirs();
				if(!file.exists())
					try {
						file.createNewFile();
					} catch (IOException e) {
						logger.error(e.getMessage(), e);
					}
			}
				
		}
		System.out.println("sync images job done, totally "+files.size()+" files synced, in "+(System.currentTimeMillis()-start)/(double)1000+" seconds");
	}
}
