package com.hoperun.c4d.storm;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.concurrent.Executors;

import org.jboss.netty.bootstrap.ServerBootstrap;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.jboss.netty.channel.group.ChannelGroup;
import org.jboss.netty.channel.group.DefaultChannelGroup;
import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;

import com.hoperun.c4d.bean.vo.APIWrapper;
import com.hoperun.c4d.bean.vo.request.AlarmRequest;
import com.hoperun.c4d.bean.vo.request.HLRequest;
import com.hoperun.c4d.bean.vo.request.PSLRequest;
import com.hoperun.c4d.bean.vo.response.AlarmResponse;
import com.hoperun.c4d.bean.vo.response.PSLResponse;
import com.hoperun.c4d.common.constant.Topics;
import com.hoperun.c4d.kafka.producer.Sink;
import com.hoperun.c4d.util.JsonHelper;
import com.hoperun.c4d.util.StormUtil;
import com.hoperun.c4d.util.TcpClient;
import com.hoperun.ubi.cache.CacheManager;

public class TCPServerSimulator {
	static final ChannelGroup allChannels = new DefaultChannelGroup("TCPServerSimulator");

	
	public static void main(String args[]){
		new TCPServerSimulator().doStartup();
	}
	
	public boolean doStartup() {
		int port = 8888;
		ServerBootstrap bootsrap = null;
		try {
			bootsrap = new ServerBootstrap(new NioServerSocketChannelFactory(Executors.newCachedThreadPool(),
					Executors.newCachedThreadPool()));
			bootsrap.setPipelineFactory(new ChannelPipelineFactory() {
				public ChannelPipeline getPipeline() throws Exception {
					ChannelPipeline pipeline = Channels.pipeline();
					pipeline.addLast("DebuggerHandler", new DebuggerHandler());
					pipeline.addLast("forwardHandler", new ForwardHandler());
					return pipeline;
				}

			});
			allChannels.add(bootsrap.bind(new InetSocketAddress(port)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public static ChannelBuffer wrapResponse(String msg) {
		ChannelBuffer buffer = ChannelBuffers.buffer(msg.length());
		buffer.writeBytes(msg.getBytes());
		return buffer;
	}

	public static String parseRequest(MessageEvent e) {
		ChannelBuffer acceptBuff = (ChannelBuffer) e.getMessage();
		return acceptBuff.toString(Charset.defaultCharset());
	}
	public class DebuggerHandler extends SimpleChannelUpstreamHandler {
		
		@Override
		public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) throws Exception {
			String message = parseRequest(e);
			System.out.println(String.format("tcp server getting message [%s]", message));
			ctx.sendUpstream(e);	
		}

		@Override
		public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
			e.getChannel().close();
		}
	}
	
	public class ForwardHandler extends SimpleChannelUpstreamHandler {
		private StringBuilder sb = new StringBuilder();
		@Override
		public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) throws Exception {
			String message = parseRequest(e);
			sb.append(message);
			APIWrapper reqeustWrapper = (APIWrapper)JsonHelper.json2Bean(sb.toString(), APIWrapper.class,false);
			if (reqeustWrapper != null) {
				sb =  new StringBuilder();
				String path = reqeustWrapper.getPath();
				path = path==null?"":path;
				String session = "";
				if ("alarm".equalsIgnoreCase(path.trim())) {
					AlarmResponse aReqesut = JsonHelper.gson2Bean(reqeustWrapper.getMessage(), AlarmResponse.class);
					session = aReqesut.getSession();
					Channel channel = (Channel) CacheManager.getLocalCache().get((session));
					if (channel != null && channel.isOpen())
						channel.write(TcpClient.wrapBuffer(JsonHelper.bean2Gson(reqeustWrapper)));
				} else if ("hl".equalsIgnoreCase(path.trim())) {
					
					System.out.println("sending hot location to all connected client");
					session = "Manager-session";
					Iterator<Channel> ite = allChannels.iterator();
					while(ite.hasNext()){
						Channel chann = ite.next();
						if (chann != null && chann.isOpen())
							chann.write(TcpClient.wrapBuffer(JsonHelper.bean2Gson(reqeustWrapper)));
					}
				} else if ("psl".equalsIgnoreCase(path.trim())) {
					PSLResponse psl = JsonHelper.gson2Bean(reqeustWrapper.getMessage(), PSLResponse.class);
					session = psl.getSession();
					Channel channel = (Channel) CacheManager.getLocalCache().get((session));
					if (channel != null && channel.isOpen())
						channel.write(TcpClient.wrapBuffer(JsonHelper.bean2Gson(reqeustWrapper)));
				}else if(Topics.ALARM_MESSAGE_NOTIFICATION.equals(reqeustWrapper.getTopic())){
					String nsession = StormUtil.globalUUID();
					Channel channel = ctx.getChannel();
					CacheManager.getLocalCache().set(nsession, channel);
					reqeustWrapper.setSession(nsession);
					Sink.send(Topics.ALARM_MESSAGE_NOTIFICATION, JsonHelper.gson2Bean(reqeustWrapper.getMessage(), AlarmRequest.class));
				}else if(Topics.PSL_NODES_SECTION.equals(reqeustWrapper.getTopic())){
					String nsession = reqeustWrapper.getSession();
					Channel channel = ctx.getChannel();
					reqeustWrapper.setSession(nsession);
					CacheManager.getLocalCache().set(nsession, channel);
					Channel ca = (Channel) CacheManager.getLocalCache().get(nsession);
					Sink.send(Topics.PSL_NODES_SECTION, JsonHelper.gson2Bean(reqeustWrapper.getMessage(), PSLRequest.class));
				}else if(Topics.HL_NODES_SECTION.equals(reqeustWrapper.getTopic())){
					String nsession = "Manager-session";
					Channel channel = ctx.getChannel();
					reqeustWrapper.setSession(nsession);
					CacheManager.getLocalCache().set(nsession, channel);
					Sink.send(Topics.HL_NODES_SECTION, JsonHelper.gson2Bean(reqeustWrapper.getMessage(),HLRequest.class));
				}
			}else
				return ;
			ctx.sendUpstream(e);
		}

		@Override
		public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
			e.getChannel().close();
		}
	}
}
