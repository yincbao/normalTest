package com.hoperun.c4d.storm;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttClientSimulator {

	private final static String userName = "admin";
	private final static String passWord = "password";
	private final static String HOST = "tcp://10.20.71.161:61613";
	private final static String TOPIC = "functionNo1/clinentNo1";
	private static MqttClient client;

	public static void doTest() throws Exception {
		client = new MqttClient(HOST, "clinentNo1", new MemoryPersistence());
		MqttConnectOptions options = new MqttConnectOptions();
		options.setCleanSession(true);
		options.setUserName(userName);
		options.setPassword(passWord.toCharArray());

		client.setCallback(new MqttCallback() {

			public void messageArrived(String arg0, MqttMessage arg1) throws Exception {
				System.out.println("Client messageArrived" + arg1.toString());
			}

			public void deliveryComplete(IMqttDeliveryToken arg0) {
				System.out.println("Client deliveryComplete");
			}

			public void connectionLost(Throwable arg0) {
				System.out.println("Client connectionLost");
				if (!client.isConnected()) {
					try {
						client.connect();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		});
		client.connect(options);
		client.subscribe(TOPIC);
	}

	public static void main(String args[]) {
		try {
			new MqttClientSimulator().doTest();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		;
	}
}
