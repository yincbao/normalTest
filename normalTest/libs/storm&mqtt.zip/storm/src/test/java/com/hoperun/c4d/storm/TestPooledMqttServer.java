package com.hoperun.c4d.storm;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hoperun.c4d.mqtt.IMqttMessage;
import com.hoperun.c4d.mqtt.pool.AbstractPooledMqttClient;
import com.hoperun.c4d.storm.etc.MqttTestMessageBean;

public class TestPooledMqttServer {

	private static final Log logger = LogFactory.getLog(ClinetSimulator.class);

	public static ApplicationContext applicationContext = null;

	@BeforeClass
	public static void setUpBeforeClass() {
		applicationContext = new ClassPathXmlApplicationContext(new String[] { "classpath*:/spring-mq-mqtt.xml" });
	}
	@Test
	public void testPublishWithWildcard(){
		AbstractPooledMqttClient mqttClient = (AbstractPooledMqttClient) applicationContext.getBean("mqttClient");
		try {
			IMqttMessage msg = new MqttTestMessageBean("session:10.20.71.24:1254>","this is a test message");
			String topicName = "functionNo1/#";
			logger.debug(String.format("publish message[%s] to topic [%s] ", msg.toString(),topicName));
			
			mqttClient.publishToAll(topicName,msg , 1, true);
		} catch (MqttPersistenceException e) {
			logger.error(e.getMessage(),e);
		} catch (MqttException e) {
			logger.error(e.getMessage(),e);
		}
	}
}
