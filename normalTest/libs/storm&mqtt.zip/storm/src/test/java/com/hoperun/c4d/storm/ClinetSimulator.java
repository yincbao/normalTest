package com.hoperun.c4d.storm;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.netty.channel.Channel;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hoperun.c4d.bean.etc.Page;
import com.hoperun.c4d.bean.po.Coordinate;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.vo.APIWrapper;
import com.hoperun.c4d.bean.vo.request.AlarmRequest;
import com.hoperun.c4d.bean.vo.request.HLRequest;
import com.hoperun.c4d.bean.vo.request.PSLRequest;
import com.hoperun.c4d.service.IOsmNodesService;
import com.hoperun.c4d.util.StormUtil;
import com.hoperun.c4d.util.TcpClient;
import com.hoperun.ubi.cache.util.JsonHelper;

public class ClinetSimulator {

	private static final Log logger = LogFactory.getLog(ClinetSimulator.class);

	public static ApplicationContext applicationContext = null;

	@BeforeClass
	public static void setUpBeforeClass() {
		applicationContext = new ClassPathXmlApplicationContext(new String[] { "classpath*:/spring-all.xml" });
	}

	public static void main(String argsp[]){
		applicationContext = new ClassPathXmlApplicationContext(new String[] { "classpath*:/spring-all.xml" });
		new ClinetSimulator().testPSL();
	}
	
	@Test
	public void testPSL() {
		int pageSize = 100;
		String session = StormUtil.globalUUID() + "-SPLITOR-";
		Coordinate coor = new Coordinate(22.1860465, 113.536955);
		IOsmNodesService osmNodeService = (IOsmNodesService) applicationContext.getBean("osmNodesService");

		Page<OsmNodes> firstPage = osmNodeService.pagingNearestNodes(new Page<OsmNodes>(pageSize, 1), 113.536955,
				22.1860465, 5.00D);
		logger.info(String.format("first page [%s]", firstPage.toString()));

		int totalRecords = firstPage.getTotal();
		int loopTime = totalRecords / pageSize;
		loopTime = totalRecords % pageSize == 0 ? loopTime : loopTime + 1;
		Object lastOne = firstPage.getLastIdx();

		PSLRequest request = new PSLRequest(coor);
		request.setNodeList(firstPage.getData());
		request.setSession(session + "1/" + loopTime);
		//Sink.send(Topics.PSL_NODES_SECTION, request);
		Channel chann = TcpClient.establish("10.20.71.24", 8888, TcpClient.wrapBuffer(JsonHelper.bean2Json(APIWrapper.build(request))));
		for (int i = 2; i <= loopTime; i++) {
			Page<OsmNodes> p = new Page<OsmNodes>(pageSize, i);
			p.setLastIdx(lastOne);
			Page<OsmNodes> page = osmNodeService.pagingNearestNodes(p, 113.536955, 22.1860465, 5.00D);
			lastOne = page.getLastIdx();
			request.setNodeList(page.getData());
			request.setSession(session + i + "/" + loopTime);
			TcpClient.send(chann,(JsonHelper.bean2Json(request)));
		}
		//TcpClient.disconn(chann);
	}

	@Test
	public void testHl() {
		Coordinate coor = new Coordinate(22.1860465, 113.536955);
		HLRequest request = new HLRequest();
		request.setCoordinate(coor);
		
		coor = new Coordinate(22.3176192, 113.9359173);
		request.setCoordinate(coor);
		TcpClient.establish("10.20.71.24", 8888, TcpClient.wrapBuffer(JsonHelper.bean2Json(APIWrapper.build(request))));		//TcpClient.disconn(chann);
		
		
		Coordinate coor2 = new Coordinate(22.1860465, 113.536955);
		HLRequest request2 = new HLRequest();
		request2.setCoordinate(coor2);
		TcpClient.establish("10.20.71.24", 8888, TcpClient.wrapBuffer(JsonHelper.bean2Json(APIWrapper.build(request2))));
		//TcpClient.disconn(chann2);
		
		
		/*Coordinate coor3 = new Coordinate(30.2340702, 120.1496701);
		HLRequest request3 = new HLRequest();
		request3.setCoordinate(coor3);
		TcpClient.establish("10.20.71.24", 8888, TcpClient.wrapBuffer(JsonHelper.bean2Json(APIWrapper.build(request3))));*/
		//TcpClient.disconn(chann3);
	}
	
	
	@Test
	public void testAlarm() {
		AlarmRequest request = new AlarmRequest();
		request.setAlarm(new String[]{"speeding","130","120"});
		long c = System.currentTimeMillis();
		request.setTime(System.currentTimeMillis());
		request.setGps(new String[]{String.valueOf(c),"113.536955","22.1860465","130"});
		Channel chann2 = TcpClient.establish("10.20.71.24", 8888, TcpClient.wrapBuffer(JsonHelper.bean2Json(APIWrapper.build(request))));

	}
}
