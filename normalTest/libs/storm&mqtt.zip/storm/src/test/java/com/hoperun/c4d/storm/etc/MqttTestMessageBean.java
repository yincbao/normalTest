package com.hoperun.c4d.storm.etc;

import com.hoperun.c4d.mqtt.IMqttMessage;
import com.hoperun.ubi.cache.util.StringUtil;

public class MqttTestMessageBean implements IMqttMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1485760227657265463L;

	@Override
	public byte[] getBytes() {
		
		return this.toString().getBytes();
	}

	public MqttTestMessageBean(String session, String payload) {
		super();
		this.session = session;
		this.payload = payload;
	}


	@Override
	public String toString(){
		session = StringUtil.nullToEmpty(session);
		payload = StringUtil.nullToEmpty(payload);
		return session+payload;
	}
	private String session;
	
	private String payload;

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

}
