package com.hoperun.c4d.mongodb;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hoperun.c4d.bean.etc.Page;
import com.hoperun.c4d.util.JsonHelper;
import com.hoperun.c4d.util.StormUtil;
import com.hoperun.c4d.util.StringUtil;
import com.hoperun.exception.ExceptionCodeEnum;
import com.hoperun.exception.MongodbException;
import com.mongodb.BasicDBObject;
import com.mongodb.CommandResult;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.DBRef;
import com.mongodb.MongoException;
import com.mongodb.WriteResult;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;
import com.mongodb.util.JSON;

/**
 * 
 * @ClassName: DaoSupport
 * @Description:
 * @author YinChangbao
 * @date Nov 5, 2015 4:31:24 PM
 * 
 * @param <T>
 */
@Repository("mDaoSupport")
public class DaoSupport<T extends java.io.Serializable> {

	private static final Log logger = LogFactory.getLog(DaoSupport.class);
	@Autowired
	protected MongoDataSource mongoDataSource;

	private static Map<String, GridFS> gridFsMap = new ConcurrentHashMap<String, GridFS>();

	public DB getDatabase(T entity) {
		return mongoDataSource.mongoClient.getDB(MongoAnnotationProcessor.getDatabase(entity.getClass()));
	}

	public DBCollection getCollection(T entity) {
		return getDatabase(entity).getCollection(MongoAnnotationProcessor.getCollection(entity.getClass()));
	}

	public GridFS getGridFS(String dbName) {
		return getGridFS(dbName, null);
	}

	public GridFS getGridFS(String dbName, String bucket) {

		GridFS fs = gridFsMap.get(getDatabase(dbName));

		if (fs == null && StringUtil.isEmpty(bucket)) {
			fs = new GridFS(getDatabase(dbName));
			gridFsMap.put(dbName, fs);
		} else if (fs == null && !StringUtil.isEmpty(bucket)) {
			fs = new GridFS(getDatabase(dbName), bucket);
			gridFsMap.put(dbName, fs);
		}
		return fs;
	}

	public DB getDatabase(String database) {
		return mongoDataSource.mongoClient.getDB(database);
	}

	public DBCollection getCollection(String database, String collection) {
		return getDatabase(database).getCollection(collection);
	}

	public String defaultDbName(T entity) {
		return MongoAnnotationProcessor.getDatabase(entity.getClass());
	}

	public String defaultCollectionName(T entity) {
		return MongoAnnotationProcessor.getDatabase(entity.getClass());
	}

	public boolean insert(String dbName, String collectionName, BasicDBObject insertObj) {
		DB db = null;
		DBCollection dbCollection = null;
		if (insertObj != null) {
			db = getDatabase(dbName);
			dbCollection = db.getCollection(collectionName);
			try {
				WriteResult result = dbCollection.insert(insertObj);
				// int n = result.getN();//no exceptions, consider as a success
				// operation
				return true;
			} catch (Exception e) {
				logger.error("insert error: " + e.getMessage(), e);
				return false;
			} finally {
				if (null != db) {
					db.requestDone();
				}
			}
		}
		return false;
	}

	public ObjectId insert(T entity) {
		if (entity == null)
			return null;
		String json = JsonHelper.bean2Json(entity);
		DBObject dbObj = (DBObject) JSON.parse(json);
		DB db = getDatabase(entity);
		DBCollection collection = getCollection(entity);
		if (collection != null) {
			try {
				collection.insert(dbObj);
				ObjectId o = null;
				return (ObjectId) dbObj.get("_id");
			} catch (Exception e) {
				logger.error("insert error: " + e.getMessage(), e);
				return null;
			} finally {
				if (null != db) {
					db.requestDone();
				}
			}

		}
		return null;
	}

	public boolean save(T entity) {
		if (entity == null)
			return false;
		String json = JsonHelper.bean2Json(entity);
		DBObject dbObj = (DBObject) JSON.parse(json);
		DB db = getDatabase(entity);
		DBCollection collection = getCollection(entity);
		if (collection != null) {
			try {
				dbObj.get("_id");
				collection.save(dbObj);
				return true;
			} catch (Exception e) {
				logger.error("insert error: " + e.getMessage(), e);
				return false;
			} finally {
				if (null != db) {
					db.requestDone();
				}
			}

		}
		return false;
	}

	public <E extends AdaptedGridFile> void saveFile(E file) {
		GridFS gridFs = getGridFS(MongoAnnotationProcessor.getDatabase(file.getClass()),
				MongoAnnotationProcessor.getBucket(file.getClass()));
		try {//nio bytebuf
			GridFSInputFile gridFSInputFile = gridFs.createFile(new FileInputStream(file.getFile()));
			gridFSInputFile.setFilename(file.getFileName());
			gridFSInputFile.setId(file.getMd5());
			gridFSInputFile.save();
		} catch (MongoException e) {
			logger.error(e.getMessage(), e);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}

	}

	public void batchInsert(List<T> entityList) {
		if (StormUtil.isEmptyCollection(entityList))
			return;
		else {
			List<DBObject> data = new ArrayList<DBObject>();
			for (T entity : entityList)
				data.add((DBObject) JSON.parse(JsonHelper.bean2Json(entity)));
			DB db = getDatabase(entityList.get(0));
			DBCollection collection = getCollection(entityList.get(0));
			if (collection != null && !StormUtil.isEmptyCollection(data)) {
				try {
					collection.insert(data);
				} catch (Exception e) {
					logger.error("batchInsert error: " + e.getMessage(), e);
				} finally {
					if (null != db) {
						db.requestDone();
					}
				}

			}
		}
	}

	public boolean delete(String dbName, String collectionName, BasicDBObject mql) {
		DB db = null;
		DBCollection dbCollection = null;
		if (mql != null) {
			db = getDatabase(dbName);
			dbCollection = db.getCollection(collectionName);
			try {
				dbCollection.remove(mql);
				return true;
			} catch (Exception e) {
				logger.error("insert error: " + e.getMessage(), e);
				return false;
			} finally {
				if (null != db) {
					db.requestDone();
				}
			}
		}
		return false;
	}

	public boolean delete(String dbName, String collectionName, String[] keys, Object[] values) {
		DB db = null;
		DBCollection dbCollection = null;
		if (keys != null && values != null) {
			if (keys.length != values.length) {
				return false;
			} else {
				try {
					db = getDatabase(dbName);
					dbCollection = db.getCollection(collectionName);
					BasicDBObject doc = new BasicDBObject();
					WriteResult result = null;
					String resultString = null;
					for (int i = 0; i < keys.length; i++) {
						doc.put(keys[i], values[i]);
					}
					result = dbCollection.remove(doc);
					resultString = result.getError();
					if (null != db) {
						try {
							db.requestDone();
							db = null;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					return (resultString != null) ? false : true;
				} catch (Exception e) {
					logger.error("delete error: " + e.getMessage(), e);
				} finally {
					if (null != db) {
						db.requestDone();
						db = null;
					}
				}
			}
		}
		return false;

	}

	public <E extends AdaptedGridFile> boolean deleteFile(Class<E> fileType,String fileName){
		GridFS gridFs = getGridFS(MongoAnnotationProcessor.getDatabase(fileType),
				MongoAnnotationProcessor.getBucket(fileType));
		try{
			gridFs.remove(fileName);
			return true;
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		
		return false;
	} 
	
	public boolean update(String dbName, String collectionName, DBObject oldValue, DBObject newValue) {
		DB db = null;
		DBCollection dbCollection = null;
		WriteResult result = null;
		String resultString = null;

		if (oldValue.equals(newValue)) {
			return true;
		} else {
			try {
				db = getDatabase(dbName);
				dbCollection = db.getCollection(collectionName);

				result = dbCollection.update(oldValue, newValue);
				resultString = result.getError();

				return (resultString != null) ? false : true;
			} catch (Exception e) {
				logger.error("update error: " + e.getMessage(), e);
			} finally {
				if (null != db) {
					db.requestDone();
					db = null;
				}
			}

		}

		return false;
	}

	public List<DBObject> find(String dbName, String collectionName, String[] keys, Object[] values, int num) {
		List<DBObject> resultList = new ArrayList<DBObject>();
		DB db = null;
		DBCollection dbCollection = null;
		DBCursor cursor = null;
		if (keys != null && values != null) {
			if (keys.length != values.length) {
				return resultList;
			} else {
				try {
					db = getDatabase(dbName);
					dbCollection = db.getCollection(collectionName);

					BasicDBObject queryObj = new BasicDBObject();

					for (int i = 0; i < keys.length; i++) {
						queryObj.put(keys[i], values[i]);
					}
					cursor = dbCollection.find(queryObj, new BasicDBObject("_id", 0));
					int count = 0;
					if (num != -1) {
						while (count < num && cursor.hasNext()) {
							resultList.add(cursor.next());
							count++;
						}
						return resultList;
					} else {
						while (cursor.hasNext()) {
							resultList.add(cursor.next());
						}
						return resultList;
					}
				} catch (Exception e) {
					logger.error("find error: " + e.getMessage(), e);
				} finally {
					if (null != cursor) {
						cursor.close();
					}
					if (null != db) {
						db.requestDone();
					}
				}
			}
		}

		return resultList;
	}

	public List<T> find(BasicDBObject mql, BasicDBObject projection, BasicDBObject sortBy, int resultSize,
			Class<T> clazz) {
		try {
			String configeDbName = MongoAnnotationProcessor.getDatabase(clazz);
			String configeCollectionName = MongoAnnotationProcessor.getCollection(clazz);
			if (StringUtil.isEmpty(configeDbName) || StringUtil.isEmpty(configeCollectionName))
				return null;
			DB db = getDatabase(configeDbName);
			DBCollection dbCollection = db.getCollection(configeCollectionName);
			if (projection == null)
				projection = new BasicDBObject("_id", 0);
			else
				projection.append("_id", 0);
			DBCursor cursor = null;
			if (sortBy != null)
				cursor = dbCollection.find(mql, projection).sort(sortBy);
			else
				cursor = dbCollection.find(mql, projection);
			// result filter _id out

			int count = 0;
			List<T> resultList = new ArrayList<T>();
			if (resultSize != -1) {
				while (count < resultSize && cursor.hasNext()) {
					resultList.add(encap(cursor.next(), clazz));

					count++;
				}
				return resultList;
			} else {
				while (cursor.hasNext()) {
					resultList.add(encap(cursor.next(), clazz));
				}
				return resultList;
			}
		} catch (Exception e) {
			logger.error("find error: " + e.getMessage(), e);
		}
		return null;
	}

	public List<T> find(BasicDBObject mql, BasicDBObject projection, int resultSize, Class<T> clazz) {
		return find(mql, projection, null, resultSize, clazz);
	}

	public DBCollection perpareCollection(Class<T> clazz) {
		String configeDbName = MongoAnnotationProcessor.getDatabase(clazz);
		String configeCollectionName = MongoAnnotationProcessor.getCollection(clazz);
		if (StringUtil.isEmpty(configeDbName) || StringUtil.isEmpty(configeCollectionName))
			return null;
		DB db = getDatabase(configeDbName);
		return db.getCollection(configeCollectionName);
	}

	public DBCollection perpareCollection(String dbName, String collection) {
		if (StringUtil.isEmpty(dbName) || StringUtil.isEmpty(collection))
			return null;
		DB db = getDatabase(dbName);
		return db.getCollection(collection);
	}

	public T findOne(BasicDBObject mql, BasicDBObject projection, Class<T> clazz) {
		try {
			DBCollection dbCollection = perpareCollection(clazz);
			if (dbCollection == null)
				return null;

			if (projection == null)
				projection = new BasicDBObject("_id", 0);
			DBObject obj = dbCollection.findOne(mql, projection);
			// result filter _id out
			return encap(obj, clazz);
		} catch (Exception e) {
			logger.error("find error: " + e.getMessage(), e);
			throw new MongodbException(ExceptionCodeEnum.mongoFindOneError, e);
		}
	}

	public List<DBObject> find(String dbName, String collectionName, BasicDBObject mql, BasicDBObject projection,
			int resultSize) {
		try {
			DB db = getDatabase(dbName);
			DBCollection dbCollection = db.getCollection(collectionName);
			DBCursor cursor = dbCollection.find(mql, projection);
			// result filter _id out

			int count = 0;
			List<DBObject> resultList = new ArrayList<DBObject>();
			if (resultSize != -1) {
				while (count < resultSize && cursor.hasNext()) {
					resultList.add(cursor.next());

					count++;
				}
				return resultList;
			} else {
				while (cursor.hasNext()) {
					resultList.add(cursor.next());
				}
				return resultList;
			}
		} catch (Exception e) {
			logger.error("find error: " + e.getMessage(), e);
		}
		return null;

	}
	
	public  <E extends AdaptedGridFile> List<File> findFile(Class<E> fileType,String fileName, boolean fuzzy,String folder){
		GridFS gridFs = getGridFS(MongoAnnotationProcessor.getDatabase(fileType),
				MongoAnnotationProcessor.getBucket(fileType));
		List<File> files = new ArrayList<File>();
		try{
			List<GridFSDBFile> gfsFiles = null;
			if(fuzzy){
				BasicDBObject obj = new BasicDBObject();
				obj.put("filename", Pattern.compile(".*"+fileName+".*"));
				gfsFiles = gridFs.find(obj);
			}else
				gfsFiles = gridFs.find(fileName);
			if(!StormUtil.isEmptyCollection(gfsFiles)){
				for(GridFSDBFile gfsFile:gfsFiles ){
					//File f = new File(System.getProperty("java.io.tmpdir"));
					String filePath = StringUtil.isEmpty(folder)?System.getProperty("java.io.tmpdir"):folder;
					File f = new File(filePath+"/"+gfsFile.getFilename());
					gfsFile.writeTo(f);
					files.add(f);
				}
			}
			
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		return files;
	}

	public boolean isExit(String dbName, String collectionName, String key, Object value) {
		DB db = null;
		DBCollection dbCollection = null;
		if (key != null && value != null) {
			try {
				db = getDatabase(dbName);
				dbCollection = db.getCollection(collectionName);
				BasicDBObject obj = new BasicDBObject();
				obj.put(key, value);

				if (dbCollection.count(obj) > 0) {
					return true;
				} else {
					return false;
				}
			} catch (Exception e) {
				logger.error("isExit error: " + e.getMessage(), e);
			} finally {
				if (null != db) {
					db.requestDone();
					db = null;
				}
			}

		}
		return false;
	}

	/**
	 * 
	 * @Description: transfer dbobject to java bean in clazz type
	 * @author YinChangbao
	 * @date Nov 6, 2015 1:39:27 PM
	 *
	 */
	private T encap(DBObject result, Class<T> clazz) {
		String t = JSON.serialize(result).trim();
		if (!StringUtil.isEmpty(t) && t.startsWith("\""))
			t = t.substring(1, t.lastIndexOf("\""));
		return JsonHelper.json2Bean(t, clazz, false);
	}

	public List<T> queryAll(Map<String, Object> condition, Map<String, Integer> projection, Class<T> clazz)
			throws MongodbException {
		if (condition == null || condition.isEmpty()) {
			logger.warn("trying to query whole collection of a model Trip, reject!");
			new MongodbException(ExceptionCodeEnum.mongoTryingQueryAll);
		}
		return find(MongdbHelper.conditions(condition), MongdbHelper.projections(projection), -1, clazz);
	}

	public T queryOne(Map<String, Object> condition, Map<String, Integer> projection, Class<T> clazz)
			throws MongodbException {
		if (condition == null) {
			logger.warn("trying to query whole collection of a model Trip, reject!");
			new MongodbException(ExceptionCodeEnum.mongoTryingQueryAll);
		}
		return findOne(MongdbHelper.conditions(condition), MongdbHelper.projections(projection), clazz);
	}

	public int count(Map<String, Object> condition, Class<T> clazz) throws MongodbException {
		DBCollection collecion = perpareCollection(clazz);
		try {
			return collecion.find(MongdbHelper.conditions(condition)).count();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return 0;
	}

	public List<DBObject> aggregate(String dbName, String colleciotn, Map<String, Object>... condition) {
		DBCollection collecion = perpareCollection(dbName, colleciotn);
		List<DBObject> li = new ArrayList<DBObject>();
		List<DBObject> re = new ArrayList<DBObject>();
		if (condition != null && condition.length > 0)
			for (Map<String, Object> c : condition)
				li.add(MongdbHelper.conditions(c));
		Iterator<DBObject> ite = collecion.aggregate(li).results().iterator();
		while (ite.hasNext())
			re.add(ite.next());
		return re;

	}

	/**
	 * 
	 * @Description: 
	 *               db.runCommand(commandName:collection,commandParameterName:vlaue
	 *               .....)
	 * @author YinChangbao
	 * @date Nov 13, 2015 11:09:35 AM
	 *
	 */
	public CommandResult runCommand(String dbName, Map<String, Object> condition) {
		DB db = getDatabase(dbName);
		return db.command(MongdbHelper.conditions(condition));

	}

	public List<T> querySort(Map<String, Object> condition, Map<String, Integer> projection, Map<String, Integer> sort,
			Class<T> clazz) throws MongodbException {
		if (condition == null || condition.isEmpty()) {
			logger.warn("trying to query whole collection of a model Trip, reject!");
			new MongodbException(ExceptionCodeEnum.mongoTryingQueryAll);
		}
		try {
			return this.find(MongdbHelper.conditions(condition), MongdbHelper.projections(projection),
					MongdbHelper.projections(sort), -1, clazz);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	public boolean dropCollection(Class<T> clazz) {
		try {
			DBCollection collecion = perpareCollection(clazz);
			collecion.drop();
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return false;

	}

	public void batchInsert(Map<T, ObjectId> map, Class<T> clazz, String ns, String attr) {
		Iterator<T> ite = map.keySet().iterator();
		List<DBObject> data = new ArrayList<DBObject>();
		DB db = getDatabase(MongoAnnotationProcessor.getDatabase(clazz));
		while (ite.hasNext()) {
			T key = ite.next();
			DBRef ref = new DBRef(db, ns, map.get(key));
			DBObject en = (DBObject) JSON.parse(JsonHelper.bean2Json(key));
			en.put(attr, ref);
			data.add(en);
		}
		DBCollection collection = perpareCollection(clazz);
		if (collection != null && !StormUtil.isEmptyCollection(data)) {
			try {
				collection.insert(data);
			} catch (Exception e) {
				logger.error("batchInsert error: " + e.getMessage(), e);
			} finally {
				if (null != db) {
					db.requestDone();
				}
			}

		}
	}

	public List<T> queryLimit(Map<String, Object> condition, Map<String, Integer> projection,
			Map<String, Integer> sort, Class<T> clazz, int limit) {
		try {
			return this.find(MongdbHelper.conditions(condition), MongdbHelper.projections(projection),
					MongdbHelper.projections(sort), -1, clazz);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	public Page<T> paging(IdentityHashMap<String, Object> condition, Map<String, Integer> projection,
			Map<String, Integer> sort, Class<T> clazz, int pageNo, int pageSize, Object lastValue) {
		if (condition == null || condition.isEmpty()) {
			logger.warn("trying to query whole collection of a model Trip, reject!");
			new MongodbException(ExceptionCodeEnum.mongoTryingQueryAll);
		}
		if (sort == null || sort.isEmpty()) {
			logger.warn("trying to paging result without sort paramter, reject!");
			new MongodbException(ExceptionCodeEnum.mongoPagingHaveNoSort);
		}
		DBCollection collection = perpareCollection(clazz);
		DBCursor limit = null;
		List<T> result = new ArrayList<T>();
		BasicDBObject objprojection = MongdbHelper.projections(projection);
		if (objprojection == null)
			objprojection = new BasicDBObject("_id", 0);
		else
			objprojection.append("_id", 0);
		if (pageNo == 1) {
			limit = collection.find(MongdbHelper.conditions(condition), objprojection)
					.sort(MongdbHelper.projections(sort)).limit(pageSize);
		} else {
			String sKey = "";
			boolean asc = true;
			for (String s : sort.keySet()) {
				sKey = s;
				if (!StringUtil.isEmpty(sKey)) {
					if (sort.get(s) != 1)
						asc = false;
					break;
				}

			}

			if (asc)
				condition.put(new String(sKey), new BasicDBObject("$gte", lastValue));
			else
				condition.put(new String(sKey), new BasicDBObject("$lte", lastValue));
			limit = collection.find(MongdbHelper.conditions(condition), objprojection)
					.sort(MongdbHelper.projections(sort)).limit(pageSize);
		}
		while (limit.hasNext())
			result.add(encap(limit.next(), clazz));
		Page<T> page = new Page<T>(pageSize, pageNo);
		page.setData(result);
		page.setTotal(count(condition, clazz));
		return page;
	}

	public GridFSDBFile getByFileName(Class<T> clazz, String fileName) {
		GridFS gridFs = getGridFS(MongoAnnotationProcessor.getDatabase(clazz),
				MongoAnnotationProcessor.getBucket(clazz));
		DBObject query = new BasicDBObject("filename", fileName);
		GridFSDBFile gridFSDBFile = gridFs.findOne(query);
		return gridFSDBFile;
	}

}
