package com.hoperun.c4d.util;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;

public class Delimiters {

	
	public static ChannelBuffer[] getApiWrapperDelimiter(){
		 return new ChannelBuffer[] {   ChannelBuffers.wrappedBuffer("{\"message\":".getBytes())};
	}
}
