package com.hoperun.c4d.storm.bolt.psl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
/**
 * 
 * ClassName: PSLProcess4AssembleNodesWayIdBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class PSLProcess4AssembleNodesWayIdBolt extends AbstractBolt{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8134319122365259430L;
	private OutputCollector collector;
	private static final Log logger = LogFactory.getLog(PSLProcess4AssembleNodesWayIdBolt.class);
	
	
	@Override
	public void execute(Tuple paramTuple) {
		OsmNodes node = (OsmNodes) paramTuple.getValue(2);
		List<OsmWays> way = (List<OsmWays>) paramTuple.getValue(3);
		try{
			IOsmWaysService omsWaysService = applicationContext.getBean(IOsmWaysService.class);
			List<OsmNodes> nodeList = Arrays.asList(node);
			omsWaysService.assembleNodes(nodeList, way);
			collector.emit(new Values(paramTuple.getString(0),paramTuple.getInteger(1),nodeList,way));
			collector.ack(paramTuple);
		}catch(Exception e){
			logger.error("error occurred, will fail this tuple",e);
			collector.fail(paramTuple);
		}
		
	}

	@Override
	public void cleanup() {
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session","nodeSize","nodesStr","waysStr"));
	}

	@Override
	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
