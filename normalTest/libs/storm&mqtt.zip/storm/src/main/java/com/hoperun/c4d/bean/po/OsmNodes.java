package com.hoperun.c4d.bean.po;

import com.hoperun.c4d.mongodb.ISODateTime;
import com.hoperun.c4d.mongodb.Mongo;

/**
 * 
 * ClassName: OsmNodes
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
@Mongo(database = "Osm", collection = "OsmNodes")
public class OsmNodes implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private boolean visible;
	private String version;
	private String changeset;
	private ISODateTime timestamp;
	private String uid;
	private String way;
	private Coordinate coordinate;

	
	
	public String getWay() {
		return way;
	}

	public void setWay(String way) {
		this.way = way;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getChangeset() {
		return changeset;
	}

	public void setChangeset(String changeset) {
		this.changeset = changeset;
	}



	public ISODateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(ISODateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Coordinate getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Coordinate coordinate) {
		this.coordinate = coordinate;
	}

	@Override
	public String toString() {
		return "OsmNodes [id=" + id + ", visible=" + visible + ", version=" + version + ", changeset=" + changeset
				+ ", timestamp=" + timestamp + ", uid=" + uid + ", way=" + way + ", coordinate=" + coordinate + "]";
	}
	
	
}
