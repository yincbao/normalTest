package com.hoperun;

import org.apache.log4j.PropertyConfigurator;

import com.hoperun.c4d.storm.topology.AlarmTopology;
import com.hoperun.c4d.storm.topology.HLTopology;
import com.hoperun.c4d.storm.topology.PSLTopology;

public class Main {
	
	
	public static void main(String args[]) {
		//PropertyConfigurator.configure("D:/work/workspace/storm/src/main/resources/log4j.properties"); 
		String nimbus = "";
		if(args!=null&&args.length>0)
			nimbus = args[0];
			//PSLTopology.publish(nimbus);
			HLTopology.publish(nimbus);
			//AlarmTopology.publish(nimbus);
	}

}
