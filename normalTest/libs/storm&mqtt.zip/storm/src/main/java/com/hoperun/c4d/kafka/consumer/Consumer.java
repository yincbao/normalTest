package com.hoperun.c4d.kafka.consumer;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Future;

import kafka.consumer.ConsumerConfig;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.IRichSpout;
import backtype.storm.topology.OutputFieldsDeclarer;

import com.hoperun.c4d.bean.etc.TupleValue;
import com.hoperun.c4d.kafka.consumer.handler.AbstractHandler;
import com.hoperun.c4d.util.ManagedThreadPool;
import com.hoperun.c4d.util.SystemConfig;

/**
 * 
 * ClassName: BaseConsumer
 * @description
 * @author yin_changbao
 * @Date   Oct 29, 2015
 *
 */
public  class Consumer {
	
	private static final Log logger = LogFactory.getLog(Consumer.class);
	
	protected  int streamAmount = 1;
	
	protected  ConsumerConnector consumer;
	
	public  String consumerId;
	
	public String topic;
	
	public String groupId;
	
	public String handler;
	
	public Consumer(String consumerId,String groupId, String topic) {
		this.consumerId = consumerId;
		this.groupId = groupId;
		this.topic = topic;
	}

	public void shutdown() {
		if (consumer != null)
			consumer.shutdown();
	}
	
	/**
	 * 
	 * subscribe for specified topic.
	 */
	public void startup() {
		logger.info("["+this.topic+" ]consumer is working...");
		consumer = kafka.consumer.Consumer.createJavaConsumerConnector(createConsumerConfig());
        Map<String, Integer> topicCountMap = new HashMap<String, Integer>();
        topicCountMap.put(this.topic, streamAmount); 
        Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap = consumer.createMessageStreams(topicCountMap);
        List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(this.topic);
        List<Future<TupleValue> > tomorrowland = new ArrayList<Future<TupleValue>>();
        for (final KafkaStream<byte[], byte[]> stream : streams){
        	try{
        		Class<AbstractHandler> clazz = (Class<AbstractHandler>) Class.forName(this.handler);
    			Constructor<AbstractHandler> costr=clazz.getConstructor(new Class[]{KafkaStream.class});
        		tomorrowland.add(ManagedThreadPool.submit(costr.newInstance(stream)));
        	}catch(Exception e ){
        		logger.error("starting consumer failed"+e.getMessage(),e);
        	}
        }
    }

	private ConsumerConfig createConsumerConfig() {
		Properties props = new Properties();
		props.put("zookeeper.connect", SystemConfig.getProperty("acc.mq.zookeeper.connect"));
		props.put("group.id", groupId);
		props.put("consumer.id", consumerId);
		props.put("zookeeper.session.timeout.ms", SystemConfig.getProperty("acc.mq.zookeeper.session.timeout.ms"));
		props.put("zookeeper.sync.time.ms", SystemConfig.getProperty("acc.mq.zookeeper.sync.time.ms"));
		props.put("auto.commit.interval.ms", SystemConfig.getProperty("acc.mq.auto.commit.interval.ms"));
		props.put("rebalance.max.retries",SystemConfig.getProperty("acc.mq.rebalance.max.retries") );
		props.put("rebalance.backoff.ms", SystemConfig.getProperty("acc.mq.rebalance.backoff.ms"));
		return new ConsumerConfig(props);
	}

}
