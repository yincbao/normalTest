package com.hoperun.c4d.bean.vo.response;

import java.util.List;

import com.hoperun.c4d.bean.po.AlarmData;
import com.hoperun.c4d.bean.po.GpsData;
import com.hoperun.c4d.common.constant.Topics;

public class AlarmResponse implements IResponse{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3432589304331779053L;
	
	private String session;
	
	private List<AlarmData> alarms;
	private List<GpsData> gps;
	

	public String getSession() {
		return session;
	}



	public void setSession(String session) {
		this.session = session;
	}


	public List<AlarmData> getAlarms() {
		return alarms;
	}



	public void setAlarms(List<AlarmData> alarms) {
		this.alarms = alarms;
	}



	public List<GpsData> getGps() {
		return gps;
	}



	public void setGps(List<GpsData> gps) {
		this.gps = gps;
	}



	public AlarmResponse(String session,List<AlarmData> alarms, List<GpsData> gps) {
		this.session = session;
		this.alarms = alarms;
		this.gps = gps;
	}

	@Override
	public String getMessagePath() {
		return "alarm";
	}



	@Override
	public String topicName() {
		return Topics.ALARM_MESSAGE_NOTIFICATION;
	}
}
