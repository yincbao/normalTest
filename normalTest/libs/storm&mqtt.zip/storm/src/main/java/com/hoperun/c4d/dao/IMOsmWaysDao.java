package com.hoperun.c4d.dao;

import java.util.List;

import com.hoperun.c4d.bean.po.OsmWays;

/**
 * 
 * ClassName: IMOsmWaysDao
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
public interface IMOsmWaysDao extends java.io.Serializable{

	
	/**
	 * query osmWays by nodeIds
	 * @param nodes
	 * @return
	 */
	public OsmWays queryByNds(String[] nodes);

	List<OsmWays> queryWaysByNds(String[] nodes);
}
