package com.hoperun.c4d.storm.bolt.hotLocation;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.StormUtil;

/**
 * 
 * ClassName: HLProcess2AssembleWayBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class HLProcess2AssembleWayBolt extends AbstractBolt {

	private static final Log logger = LogFactory.getLog(HLProcess2AssembleWayBolt.class);
	private static final long serialVersionUID = 886149197481637894L;

	public void cleanup() {
	}

	public void execute(Tuple paramTuple) {

		try {
			IOsmWaysService osmWaysService = applicationContext.getBean(IOsmWaysService.class);
			OsmNodes node = (OsmNodes) paramTuple.getValueByField("nodeIn1");
			List<OsmWays> ways = osmWaysService.fetchSpeedLimit(Arrays.asList(node));
		
			if (!StormUtil.isEmptyCollection(ways)){
				OsmWays way = ways.get(0);
				String[] fixedNodes = new String[1];
				if(way.getNds()!=null||way.getNds().length>0){
					String[] nodes = way.getNds();
					fixedNodes[0]=nodes[0];
					way.setNds(fixedNodes);
				}
					 
				collector.emit(new Values(ways.get(0), 1));
			}
				
			collector.ack(paramTuple);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			collector.fail(paramTuple);
		}

	}

	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("wayIn2", "count"));
	}

	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
