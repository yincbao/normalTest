package com.hoperun.c4d.common.constant;

public interface Topics {
	
	
	public final String PSL_NODES_SECTION = "PSL_NODES_SECTION_4_1";
	
	public final String PSL_STORM_OUTPUT = "PSL_STORM_OUTPUT";
	
	public final String HL_NODES_SECTION = "HL_NODES_SECTION";
	
	public final String ALARM_MESSAGE_NOTIFICATION = "ALARM_MESSAGE_NOTIFICATION";

}
