package com.hoperun.c4d.bean.vo.request;

import com.hoperun.c4d.bean.po.Coordinate;
import com.hoperun.c4d.common.constant.Topics;
import com.hoperun.exception.ExceptionCodeEnum;
import com.hoperun.exception.InterfaceException;
import com.hoperun.ubi.cache.util.StringUtil;

public class HLRequest implements IRequest {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7202482604972556669L;

	private Coordinate coordinate;
	
	private String session;

	@Override
	public String getSession() {
		return session;
	}

	@Override
	public void validate() throws InterfaceException {
		if(StringUtil.isEmpty(session))
			throw new InterfaceException(ExceptionCodeEnum.INTERFACE_EXCEPTION_NO_SESSION_SPECIFIED);
		if(coordinate==null)
			throw new InterfaceException(ExceptionCodeEnum.INTERFACE_EXCEPTION_INVALID_COORDINATE);
	}

	public Coordinate getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Coordinate coordinate) {
		this.coordinate = coordinate;
	}

	public void setSession(String session) {
		this.session = session;
	}

	@Override
	public String getMessagePath() {
		return "";
	}

	@Override
	public String topicName() {
		return Topics.HL_NODES_SECTION;
	}
	
	
}
