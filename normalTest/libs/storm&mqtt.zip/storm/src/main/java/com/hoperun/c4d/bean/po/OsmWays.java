package com.hoperun.c4d.bean.po;

import java.util.Arrays;

import com.hoperun.c4d.mongodb.ISODateTime;
import com.hoperun.c4d.mongodb.Mongo;

/**
 * 
 * ClassName: OsmWays
 * 
 * @description
 * @author yin_changbao
 * @Date Dec 8, 2015
 *
 */
@Mongo(database = "Osm", collection = "OsmWays")
public class OsmWays implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private boolean visible;
	private String version;
	private String changeset;
	private ISODateTime timestamp;
	private String uid;
	private String[] nds;
	private String highway;
	private Double maxspeed;

	private Double postLat;
	private Double pstLon;

	public Double getPostLat() {
		return postLat;
	}

	public void setPostLat(Double postLat) {
		this.postLat = postLat;
	}

	public Double getPstLon() {
		return pstLon;
	}

	public void setPstLon(Double pstLon) {
		this.pstLon = pstLon;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getChangeset() {
		return changeset;
	}

	public void setChangeset(String changeset) {
		this.changeset = changeset;
	}

	public ISODateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(ISODateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String[] getNds() {
		return nds;
	}

	public void setNds(String[] nds) {
		this.nds = nds;
	}

	public String getHighway() {
		return highway;
	}

	public void setHighway(String highway) {
		this.highway = highway;
	}

	public Double getMaxspeed() {
		return maxspeed;
	}

	public void setMaxspeed(Double maxspeed) {
		this.maxspeed = maxspeed;
	}

	@Override
	public final int hashCode() {
		int hashCode = 17;
		hashCode = hashCode * 13 + this.id.hashCode();
		hashCode = hashCode + this.highway.hashCode();
		return hashCode;
	}

	@Override
	public final boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (this == obj)
			return true;
		if (obj instanceof OsmWays) {
			int hash = ((OsmWays) obj).hashCode();
			if (this.hashCode() == hash) {
				return true;
			}
		} else {
			return false;
		}
		return false;
	}

	@Override
	public String toString() {
		return "OsmWays [id=" + id + ", visible=" + visible + ", version=" + version + ", changeset=" + changeset
				+ ", timestamp=" + timestamp + ", uid=" + uid + ", nds=" + Arrays.toString(nds) + ", highway="
				+ highway + ", maxspeed=" + maxspeed + ", postLat=" + postLat + ", pstLon=" + pstLon + "]";
	}
	
	
}
