package com.hoperun.c4d.util;

import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelUpstreamHandler;
import org.jboss.netty.channel.socket.nio.NioClientSocketChannelFactory;

import com.hoperun.exception.ExceptionCodeEnum;
import com.hoperun.exception.NetworkException;

/**
 * 
 * ClassName: TcpClient
 * 
 * @description
 * @author yin_changbao
 * @Date Jan 22, 2016
 *
 */
public final class TcpClient {

	private static final Log logger = LogFactory.getLog(TcpClient.class);

	static ExecutorService bossExecutor = Executors.newCachedThreadPool();
	static ExecutorService workerExecutor = Executors.newCachedThreadPool();
	
	private static String host = SystemConfig.getProperty("acc.tcp.server.host","localhost");
	private static int port = SystemConfig.getIntProperty("acc.tcp.server.port",8888);

	private static Channel channel = null;
	private TcpClient(){
		TcpClient.channel = establish( host,  port, null);
	}
	
	private static class SingletonHolder {
		private static final TcpClient INSTANCE = new TcpClient();
	}

	public static final TcpClient getInstance() {
		return SingletonHolder.INSTANCE;
	}
	
	/**
	 * establish an connection with server.
	 * @param host
	 * @param port
	 * @param buffer
	 * @return
	 */
	public static Channel establish(String host, int port, ChannelBuffer buffer) {
		ChannelFactory channelFactory = new NioClientSocketChannelFactory(bossExecutor, workerExecutor);
		ClientBootstrap bootstarp = new ClientBootstrap(channelFactory);
		bootstarp.setPipelineFactory(new ChannelPipelineFactory() {

			public ChannelPipeline getPipeline() throws Exception {

				ChannelPipeline pipeline = Channels.pipeline();
				pipeline.addLast("handler", new SimpleChannelUpstreamHandler() {
					@Override
					public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) throws Exception {
						logger.info("message Received " + parseRequest(e));
						ctx.sendUpstream(e);
					}

					@Override
					public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) throws Exception {
						logger.info("exceptionCaught e is " + e.getCause());
					}
				});
				return pipeline;

			}
		});

		ChannelFuture future = bootstarp.connect(new InetSocketAddress(host, port));
		future.awaitUninterruptibly();
		if (future.isSuccess()) {
			Channel channel = future.getChannel();
			if (buffer != null)
				channel.write(buffer);
			return channel;
		}
		return null;

	}

	public static ChannelBuffer wrapBuffer(String msg) {
		ChannelBuffer buffer = ChannelBuffers.buffer(msg.length());
		buffer.writeBytes(msg.getBytes());
		return buffer;
	}
	public static String parseRequest(MessageEvent e) {
		ChannelBuffer acceptBuff = (ChannelBuffer) e.getMessage();
		return acceptBuff.toString(Charset.defaultCharset());
	}
	public static boolean send(Channel channel,String message){
		if(channel==null||!channel.isConnected()||!channel.isOpen())
			throw new NetworkException(ExceptionCodeEnum.NETWORK_INVALID_CHANNEL);
		try{
			channel.write(wrapBuffer(message));
			return true;
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		return false;
		
	}
	
	
	public static boolean disconn(Channel channel){
		if(channel !=null){
			try{
				channel.unbind();
				channel.close();
				return true;
			}catch(Exception e){
				logger.error(e.getMessage(),e);
				return false;
			}
			
		}
		return true;
	}
	public static boolean send(String message,boolean establishNewChannle){
		try{
			if(establishNewChannle){
				disconn(establish( host,  port, wrapBuffer(message)));
			}else{
				if(channel==null||!channel.isOpen()||!channel.isConnected())
					channel = establish( host,  port, null);
				channel.write(wrapBuffer(message));
			}
			return true;
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			return false;
		}
	}
}
