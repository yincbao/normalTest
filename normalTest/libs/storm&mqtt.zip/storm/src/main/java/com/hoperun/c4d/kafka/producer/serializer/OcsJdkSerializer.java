package com.hoperun.c4d.kafka.producer.serializer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import kafka.serializer.Encoder;
import kafka.utils.VerifiableProperties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoperun.c4d.bean.vo.IMessage;

/**
 * 
 * ClassName: AccSerializer
 * 
 * @description
 * @author yin_changbao
 * @Date Oct 29, 2015
 *
 */
public class OcsJdkSerializer implements Encoder<IMessage> {

	private static final Log logger = LogFactory.getLog(OcsJdkSerializer.class);

	public OcsJdkSerializer(VerifiableProperties props) {
	}

	public byte[] toBytes(IMessage paramT) {
		if (paramT != null) {
			ByteArrayOutputStream bos = null;
			ObjectOutputStream oo = null;
			try {
				bos = new ByteArrayOutputStream();
				oo = new ObjectOutputStream(bos);
				oo.writeObject(paramT);

				return bos.toByteArray();

			} catch (Exception e) {
				logger.error("AccSerializer error ", e);
			} finally {
				if (bos != null)
					try {
						bos.close();
					} catch (IOException e) {
					}
				if (oo != null)
					try {
						oo.close();
					} catch (IOException e) {
					}
			}

		}
		return null;
	}
}
