package com.hoperun.c4d.dao;

import java.util.List;

import com.hoperun.c4d.bean.etc.Page;
import com.hoperun.c4d.bean.po.OsmNodes;

/**
 * 
 * ClassName: IMOsmNodesDao
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
public interface IMOsmNodesDao extends java.io.Serializable{

	/**
	 * find the nearest node within max distance from (longitude,latitude)
	 * @param longitude
	 * @param latitude
	 * @param maxDistance
	 * @return
	 */
	public OsmNodes findNearestNode(Double longitude,Double latitude,Double maxDistance);

	List<OsmNodes> findNearestNodes(Double longitude, Double latitude, Double maxDistance);
	
	public Page<OsmNodes> pagingNearestNodes(Page<OsmNodes> page,Double longitude, Double latitude, Double maxDistance);

}
