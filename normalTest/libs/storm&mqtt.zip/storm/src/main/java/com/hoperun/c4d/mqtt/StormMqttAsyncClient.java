package com.hoperun.c4d.mqtt;

import java.util.Hashtable;

import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttClientPersistence;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.eclipse.paho.client.mqttv3.TimerPingSender;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 * 
 * ClassName: StormMqttAsyncClient
 * @description
 * @author yin_changbao
 * @Date   Jan 29, 2016
 *
 */
@SuppressWarnings("rawtypes")
public class StormMqttAsyncClient extends MqttAsyncClient {

	private String clientId;
	private String serverURI;
	private  Hashtable topics;
	private MqttClientPersistence persistence;
	public StormMqttAsyncClient(String serverURI, String clientId) throws MqttException {
		super(serverURI, clientId);
	}

	public StormMqttAsyncClient(String serverURI, String clientId, MqttClientPersistence persistence) throws MqttException {
		super(serverURI, clientId, persistence, new TimerPingSender());
		this.serverURI = serverURI;
		this.clientId = clientId;

		this.persistence = persistence;
		if (this.persistence == null) {
			this.persistence = new MemoryPersistence();
		}


		this.persistence.open(clientId, serverURI);
		this.persistence.close();
		this.topics = new Hashtable();
	}
	
	protected MqttTopic getTopic(String topic, boolean allowWildcard) {
		MqttTopic.validate(topic, allowWildcard);

		MqttTopic result = (MqttTopic) this.topics.get(topic);
		if (result == null) {
			result = new MqttTopic(topic, this.comms);
			this.topics.put(topic, result);
		}
		return result;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getServerURI() {
		return serverURI;
	}

	public void setServerURI(String serverURI) {
		this.serverURI = serverURI;
	}

	public Hashtable getTopics() {
		return topics;
	}

	public void setTopics(Hashtable topics) {
		this.topics = topics;
	}

	public MqttClientPersistence getPersistence() {
		return persistence;
	}

	public void setPersistence(MqttClientPersistence persistence) {
		this.persistence = persistence;
	}
}
