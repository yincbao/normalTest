package com.hoperun.c4d.bean.etc;

import java.util.concurrent.atomic.AtomicInteger;

public class ReaptCounter<E extends java.io.Serializable> implements java.io.Serializable,Comparable<ReaptCounter<E>>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private E attr;
	
	private AtomicInteger counter;


	public E getAttr() {
		return attr;
	}

	public void setAttr(E attr) {
		this.attr = attr;
	}

	public AtomicInteger getCounter() {
		return counter;
	}

	public void setCounter(AtomicInteger counter) {
		this.counter = counter;
	}

	public ReaptCounter(E attr, AtomicInteger counter) {
		super();
		this.attr = attr;
		this.counter = counter;
	}

	public ReaptCounter() {
		super();
	}

	@Override
	public int compareTo(ReaptCounter<E> o) {
		if(o==null)
			return 1 ;
		if(this.attr==null)
			return -1;
		return (int) -(this.counter.get()-o.counter.get());
	}


}
