package com.hoperun.c4d.bean.vo.response;

import com.hoperun.c4d.bean.vo.IMessage;

public interface IResponse extends IMessage{
	

}
