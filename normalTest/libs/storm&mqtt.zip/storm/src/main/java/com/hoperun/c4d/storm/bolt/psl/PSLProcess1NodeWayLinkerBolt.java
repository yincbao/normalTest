package com.hoperun.c4d.storm.bolt.psl;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.bean.vo.request.PSLRequest;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.StormUtil;

/**
 * 
 * ClassName: PSLProcess1NodeWayLinkerBolt
 * @description
 * @author yin_changbao
 * @Date   Jan 27, 2016
 *
 */
public class PSLProcess1NodeWayLinkerBolt extends AbstractBolt {

	private static final Log logger = LogFactory.getLog(PSLProcess1NodeWayLinkerBolt.class);
	private static final long serialVersionUID = 886149197481637894L;
	

	public void cleanup() {
	}

	public void execute(Tuple paramTuple) {
		try{
			IOsmWaysService osmWaysService = applicationContext.getBean(IOsmWaysService.class);
			PSLRequest message = (PSLRequest) paramTuple.getValues().get(0);
			logger.debug(String.format("original message from kafkaSpout [%s]", message.toString()));
			List<OsmNodes> dataList = message.getNodeList();
			if(!StormUtil.isEmptyCollection(dataList)){
				for(OsmNodes osmNode:dataList){// distribute data 
					List<OsmWays> way = osmWaysService.fetchSpeedLimit(Arrays.asList(osmNode)) ;
					if(!StormUtil.isEmptyCollection(way))
						collector.emit(new Values(message.getSession(),dataList.size(),osmNode,way,message.getCoordinate()));
				}
			}
			collector.ack(paramTuple);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			collector.fail(paramTuple);
		}
		
	}

	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session","nodeSize","node","way","coordinate"));
	}

	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
