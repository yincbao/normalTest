package com.hoperun.c4d.mqtt.pool;

import org.apache.commons.pool2.BasePooledObjectFactory;

import com.hoperun.c4d.mqtt.IMqttClient;

/**
 * 
 * ClassName: ComboPooledMqttClient
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class ComboPooledMqttClient extends AbstractPooledMqttClient{
	

	private String host;
	private String userName;
	private String password;
	private String clientId;
	
	private int connectionTimeout;
	private int keepAliveInterval;
	private boolean cleanSession;
	private boolean useMemoryPersistence;
	private String dataDir;
	private int maxTotal = 20;
	private int maxIdle;
    private int minIdle;
    
	
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public int getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public int getKeepAliveInterval() {
		return keepAliveInterval;
	}

	public void setKeepAliveInterval(int keepAliveInterval) {
		this.keepAliveInterval = keepAliveInterval;
	}

	public boolean isCleanSession() {
		return cleanSession;
	}

	public void setCleanSession(boolean cleanSession) {
		this.cleanSession = cleanSession;
	}

	public boolean isUseMemoryPersistence() {
		return useMemoryPersistence;
	}

	public void setUseMemoryPersistence(boolean useMemoryPersistence) {
		this.useMemoryPersistence = useMemoryPersistence;
	}

	public String getDataDir() {
		return dataDir;
	}

	public void setDataDir(String dataDir) {
		this.dataDir = dataDir;
	}

	public int getMaxIdle() {
		return maxIdle;
	}

	public void setMaxIdle(int maxIdle) {
		this.maxIdle = maxIdle;
	}

	public int getMinIdle() {
		return minIdle;
	}

	public void setMinIdle(int minIdle) {
		this.minIdle = minIdle;
	}

	public ComboPooledMqttClient() {
		super();
		BasePooledObjectFactory<IMqttClient> factory = new PooledMqttClientFactory();
		this.pool = new Pool(factory, new Config(maxTotal,maxIdle,minIdle));
		this.pool.setMaxWaitMillis(3*1000);
				
	}

	public int getMaxTotal() {
		return maxTotal;
	}

	public void setMaxTotal(int maxTotal) {
		this.maxTotal = maxTotal;
	}
	
	
}
