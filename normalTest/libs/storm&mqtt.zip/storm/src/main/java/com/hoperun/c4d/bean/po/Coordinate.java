package com.hoperun.c4d.bean.po;
/**
 * 
 * 
* @ClassName: Coordinate.java 
* @Description: 
* @author YinChang-bao
* @date Nov 16, 2015
*
 */
public class Coordinate implements java.io.Serializable{
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 2041193361746667241L;

	private Double latitude;
	
	private Double longitude;

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Coordinate(Double latitude, Double longitude) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public Coordinate() {
		super();
	}

	@Override
	public String toString() {
		return "Coordinate [latitude=" + latitude + ", longitude=" + longitude + "]";
	}
	
}
