package com.hoperun.c4d.util;
public enum APIWrapperDecoderState {
		ReadA, ReadBCDEFG
	}