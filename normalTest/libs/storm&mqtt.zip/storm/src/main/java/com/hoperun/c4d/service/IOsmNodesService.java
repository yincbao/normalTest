package com.hoperun.c4d.service;

import java.util.List;

import com.hoperun.c4d.bean.etc.Page;
import com.hoperun.c4d.bean.po.OsmNodes;

public interface IOsmNodesService extends java.io.Serializable{

	public OsmNodes findNearestNode(Double longitude, Double latitude, Double maxDistance);

	List<OsmNodes> findNearestNodes(Double longitude, Double latitude, Double maxDistance);
	
	public Page<OsmNodes> pagingNearestNodes(Page<OsmNodes> page ,Double longitude, Double latitude, Double maxDistance);
}
