package com.hoperun.c4d.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hoperun.c4d.bean.po.OsmHighWayMaxSpeed;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.common.constant.StormConstants;
import com.hoperun.c4d.dao.IMOsmNodesDao;
import com.hoperun.c4d.dao.IMOsmWaysDao;
import com.hoperun.c4d.dao.IOsmDefaultHighwayMaxSpeedDao;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.util.HttpClientHelper;
import com.hoperun.c4d.util.StringUtil;

/**
 * 
 * ClassName: PostSpeedLimitServiceImpl
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
@Service
public class OsmWaysServiceImpl implements IOsmWaysService {

	
	private static final Log logger = LogFactory.getLog(OsmWaysServiceImpl.class);

	@Autowired
	protected IMOsmNodesDao mOsmNodesDao;
	
	@Autowired
	protected IMOsmWaysDao mOsmWaysDao;
	
	@Autowired
	protected IOsmDefaultHighwayMaxSpeedDao osmDefaultHighwayMaxSpeedDao;
	
	public List<OsmWays> fetchSpeedLimit(Double longitude, Double latitude,Double range) {
		logger.info(" service PostSpeedLimitServiceImpl.fetchSpeedLimit entered, with input parameters: longitude"+longitude+"|latitude"+latitude);
		List<OsmNodes> nodes = mOsmNodesDao.findNearestNodes(longitude, latitude, range);
		if(nodes==null||nodes.isEmpty()){
			logger.debug("no osm node match condition:("+longitude+","+latitude+") range: "+range);
			return null;
		}
		//Map<String,OsmNodes> nodeMap = list2Map(nodes);
		List<OsmWays> osmWays = mOsmWaysDao.queryWaysByNds(wrapNodeIds(nodes));
		if(osmWays!=null&&!osmWays.isEmpty()){
			try {
				assembleWays(osmWays,longitude,latitude);
			} catch (Exception e) {
				logger.debug(e.getMessage(),e);
			}
		}
		return osmWays;
	}
	
	public List<OsmWays> fetchSpeedLimit(List<OsmNodes> nodes) {
		if(nodes==null||nodes.isEmpty())
			return null;
		logger.info(" service PostSpeedLimitServiceImpl.fetchSpeedLimit entered,nodes amount:"+nodes.size());
		//Map<String,OsmNodes> nodeMap = list2Map(nodes);
		return mOsmWaysDao.queryWaysByNds(wrapNodeIds(nodes));
		/*if(osmWays!=null&&!osmWays.isEmpty()){
			try {
				assembleWays(osmWays,nodes.get(0).getCoordinate().getLongitude(),nodes.get(0).getCoordinate().getLatitude());//just location country and district
			} catch (Exception e) {
				logger.debug(e.getMessage(),e);
			}
		}*/
		//return osmWays;
	}

	private String[] wrapNodeIds(List<OsmNodes> nodes) {
		String[] nodeIds = new String[nodes.size()];
		for(int i = 0;i<nodes.size();i++)
			nodeIds[i]= nodes.get(i).getId();
		return nodeIds;
	}
	private String [] hongkongTaiwan(String country,String district){
		String[] result = new String[2];
		if(!StringUtil.isEmpty(country)&&StormConstants.XIANGGANG.equalsIgnoreCase(country)){
			result[0]=StormConstants.CHINA;
			result[1]=district+", "+StormConstants.XIANGGANG;
		}else if(!StringUtil.isEmpty(country)&&StormConstants.TAIWAN.equalsIgnoreCase(country)){
			result[0]=StormConstants.CHINA;
			result[1]=district+", "+StormConstants.TAIWAN;
		}else if(!StringUtil.isEmpty(country)&&StormConstants.AOMEN.equalsIgnoreCase(country)){
			result[0]=StormConstants.CHINA;
			result[1]=district+", "+StormConstants.AOMEN;
		}else{
			result[0]=country;
			result[1]=district;
		}
		return 	result;
	}
	public String[] assembleWaysName(Double longitude, Double latitude){
		String googleLBSUrl = String.format(StormConstants.GOOGLE_LOCATION_QURTY_URL, latitude,longitude);
		String detailAddress = "";
		
		String country = StormConstants.MEXICO;
		String district = "";
		String googleLBResponse = "";//HttpClientHelper.doGet(googleLBSUrl);
		logger.debug("location service request String: "+googleLBSUrl+" || response: " + googleLBResponse);
		if(!StringUtil.isEmpty(googleLBResponse)){
			JSONObject object = null;
			try {
				object = new JSONObject(googleLBResponse);
			} catch (JSONException e) {
				logger.error(e.getMessage(),e);
			}
			if (null != object) {
				String status = object.optString("status");
				if(status!=null&&status.equalsIgnoreCase("OK")){
					JSONArray root = object.optJSONArray("results");
					JSONObject road = root.optJSONObject(0);
					detailAddress = road.optString("formatted_address");
				}
			}
			if(!StringUtil.isEmpty(detailAddress)){
				String[] temp  = detailAddress.split(",");
				int index = temp.length;
				country = temp[index-1];
				if(index>=2)
					district = temp[index-2];
			}
		}
		
		return  hongkongTaiwan( country, district);
	}
	
	
	public void assembleWaysMaxSpeed(List<OsmWays> osmWays,String[] area) {
		
		String[] ming = area;
		String country = ming[0];
		String district = ming[1];
		for(OsmWays way:osmWays){
			if(way!=null&&way.getMaxspeed()<=0){
				OsmHighWayMaxSpeed condition = new OsmHighWayMaxSpeed();
				condition.setCountry(country);
				condition.setDistrict(district);
				condition.setHighway(way.getHighway());
				List<OsmHighWayMaxSpeed> highwayList = osmDefaultHighwayMaxSpeedDao.queryDefaultMaxSpeedByCondition(condition);
				if(highwayList!=null&&!highwayList.isEmpty())
					way.setMaxspeed(highwayList.get(0).getMaxSpeed());
			}
		}
	}
	
	public void assembleWays(List<OsmWays> osmWays,Double longitude, Double latitude) throws Exception{
		String googleLBSUrl = String.format(StormConstants.GOOGLE_LOCATION_QURTY_URL, latitude,longitude);
		String detailAddress = "";
		
		String country = StormConstants.MEXICO;
		String district = "";
		String googleLBResponse = HttpClientHelper.doGet(googleLBSUrl);
		logger.debug("location service request String: "+googleLBSUrl+" || response: " + googleLBResponse);
		JSONObject object = new JSONObject(googleLBResponse);
		if (null != object) {
			String status = object.optString("status");
			if(status!=null&&status.equalsIgnoreCase("OK")){
				JSONArray root = object.optJSONArray("results");
				JSONObject road = root.optJSONObject(0);
				detailAddress = road.optString("formatted_address");
			}
		}
		if(!StringUtil.isEmpty(detailAddress)){
			String[] temp  = detailAddress.split(",");
			int index = temp.length;
			country = temp[index-1];
			if(index>=2)
				district = temp[index-2];
		}
		String[] ming = hongkongTaiwan( country, district);
		country = StringUtil.isEmpty(ming[0])?country:ming[0];
		district =  StringUtil.isEmpty(ming[1])?district:ming[1];
		for(OsmWays way:osmWays){
			if(way!=null&&way.getMaxspeed()!=null&&way.getMaxspeed()<=0){
				OsmHighWayMaxSpeed condition = new OsmHighWayMaxSpeed();
				condition.setCountry(country);
				condition.setDistrict(district);
				condition.setHighway(way.getHighway());
				List<OsmHighWayMaxSpeed> highwayList = osmDefaultHighwayMaxSpeedDao.queryDefaultMaxSpeedByCondition(condition);
				if(highwayList!=null&&!highwayList.isEmpty())
					way.setMaxspeed(highwayList.get(0).getMaxSpeed());
			}
		}
	}
	
	
	@Deprecated
	private Map<String,OsmNodes> list2Map(List<OsmNodes> nodes){
		Map<String,OsmNodes> map = new HashMap<String,OsmNodes>();
		for(OsmNodes node:nodes )
			map.put(node.getId(), node);
		return map;
	}
	
	public void assembleNodes(List<OsmNodes> osmNodes,List<OsmWays> osmWays){
		for(OsmNodes node:osmNodes){
			String nodeId = node.getId();
			for(OsmWays way:osmWays){
				String[] nds = way.getNds();
				if(nds==null||nds.length<1)
					continue;
				if(Arrays.asList(nds).contains(nodeId)){
					node.setWay(way.getId());
					continue;
				}
					
					
			}
		}
	}
	
}
