package com.hoperun.c4d.storm.bolt.psl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.ManagedThreadPool;
import com.hoperun.c4d.util.MergeThread;
/**
 * 
 * ClassName: PSLProcess5MergeBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class PSLProcess5MergeBolt extends AbstractBolt {

	private static final Log logger = LogFactory.getLog(PSLProcess5MergeBolt.class);
	/**
	 * 
	 */
	private static final long serialVersionUID = 1809703604738595504L;
	private OutputCollector collector;
	private Map<String, List<OsmNodes>> sessionNodes = null;
	private Map<String, List<OsmWays>> sessionWays = null;
	private Map<String, MergeThread> sessionThread = null;
	private Map<String, Future<Boolean>> sessionFuture = null;

	public void prepare(Map paramMap, TopologyContext paramTopologyContext, OutputCollector paramOutputCollector) {
		super.prepare(paramMap, paramTopologyContext, paramOutputCollector);
		this.collector = paramOutputCollector;
		this.sessionNodes = new ConcurrentHashMap<String, List<OsmNodes>>();
		this.sessionWays = new ConcurrentHashMap<String, List<OsmWays>>();
		this.sessionThread = new ConcurrentHashMap<String, MergeThread>();
		this.sessionFuture = new ConcurrentHashMap<String, Future<Boolean>>();
	}

	@Override
	public void execute(Tuple paramTuple) {
		String session = paramTuple.getString(0);
		int nodeSize = paramTuple.getIntegerByField("nodeSize");
		List<OsmNodes> nodeList = (List<OsmNodes>) paramTuple.getValue(2);
		List<OsmWays> wayList = (List<OsmWays>) paramTuple.getValue(3);
		try {
			IOsmWaysService omsWaysService = applicationContext.getBean(IOsmWaysService.class);
			omsWaysService.assembleNodes(nodeList, wayList);
			collector.ack(paramTuple);
			group(session,nodeSize, nodeList, wayList);
		} catch (Exception e) {
			logger.error("error occurred, will fail this tuple", e);
			collector.fail(paramTuple);
		}

	}

	/**
	 * session should be like "XXXXXXXXXXXXXXXXXX-SPLITOR-X/X"
	 * 
	 * @param session
	 * @param nodeSize 
	 * @param nodeList
	 * @param wayList
	 */
	private void group(String session, int nodeSize, List<OsmNodes> nodeList, List<OsmWays> wayList) {
		MergeThread thread = sessionThread.get(session);
		Future<Boolean> future = sessionFuture.get(session);
		if(thread==null){
			thread = new MergeThread(session,nodeSize,sessionNodes,sessionWays,applicationContext);
			sessionThread.put(session, thread);
			sessionFuture.put(session, ManagedThreadPool.submit(thread));
		}else if(thread!=null&&!future.isDone()){
			thread.add(nodeList.get(0), wayList.get(0));
		}
	}


	@Override
	public void cleanup() {

	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session", "nodesStr", "waysStr"));
	}

	@Override
	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
