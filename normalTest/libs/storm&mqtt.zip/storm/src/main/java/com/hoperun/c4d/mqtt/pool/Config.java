package com.hoperun.c4d.mqtt.pool;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

/**
 * 
 * ClassName: Config
 * @description
 * @author yin_changbao
 * @Date   Jan 29, 2016
 *
 */
public class Config extends GenericObjectPoolConfig {
	public Config(int maxTotal,int maxIdle,int minIdle) {
		this.setMaxTotal(maxTotal);
		this.setBlockWhenExhausted(true);
		this.setNumTestsPerEvictionRun(Integer.MAX_VALUE);
		this.setTestOnBorrow(true);
		this.setTestOnReturn(false);
		this.setTestWhileIdle(false);
		this.setTimeBetweenEvictionRunsMillis(1 * 60000L);
		this.setMinEvictableIdleTimeMillis(10 * 60000L);
		this.setTestWhileIdle(false);
		this.setMaxIdle(maxIdle);
		this.setMinIdle(minIdle);
	}

}
