package com.hoperun.c4d.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.dao.IMOsmWaysDao;
import com.hoperun.c4d.mongodb.DaoSupport;
import com.hoperun.c4d.util.StormUtil;
import com.mongodb.BasicDBObject;

/**
 * 
 * ClassName: MOsmWaysDaoImpl
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
@Repository
public class MOsmWaysDaoImpl extends DaoSupport<OsmWays> implements IMOsmWaysDao {

	
	private static final Log logger = LogFactory.getLog(MOsmWaysDaoImpl.class);
	/*
	 * (non-Javadoc)
	 * @see com.hoperun.ubi.persistence.mongo.IMOsmWaysDao#queryByNds(java.lang.String[])
	 */
	public OsmWays queryByNds(String[] nodes) {
		if(nodes==null){
			logger.debug("empty nodes array ...");
			return null;
		}
		Map<String,Object> mql = new HashMap<String,Object>();
		mql.put("nds", new BasicDBObject("$in",nodes));
		
		try{
			List<OsmWays> result = this.queryLimit(mql,null,null, OsmWays.class,1);
			return StormUtil.isEmptyCollection(result)?null:result.get(0);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		
		return null;
	}
	
	public List<OsmWays> queryWaysByNds(String[] nodes) {
		if(null==(nodes)){
			logger.debug("empty nodes array ...");
			return null;
		}
		Map<String,Object> mql = new HashMap<String,Object>();
		mql.put("nds", new BasicDBObject("$in",nodes));
		
		try{
			return this.queryAll(mql,null, OsmWays.class);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		
		return null;
	}

}
