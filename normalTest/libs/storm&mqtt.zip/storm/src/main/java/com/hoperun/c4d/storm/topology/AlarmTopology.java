package com.hoperun.c4d.storm.topology;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import storm.kafka.BrokerHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.ZkHosts;
import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.topology.TopologyBuilder;

import com.hoperun.c4d.common.constant.Topics;
import com.hoperun.c4d.storm.bolt.alarm.AlarmParserBolt;
import com.hoperun.c4d.storm.bolt.alarm.GpsParserBolt;
import com.hoperun.c4d.storm.scheme.IMessahgeSchema;
import com.hoperun.ubi.cache.util.StringUtil;

public class AlarmTopology {
	
	private static final Log logger = LogFactory.getLog(AlarmTopology.class);
	
	public static void publish(String nimbusHost) {
		String topoName = "ALARM";
		String zks = "dev1:2181,dev2:2181,dev3:2181";
		String topic = Topics.ALARM_MESSAGE_NOTIFICATION;
		String zkRoot = "/storm"; // default zookeeper root configuration for
		String id = "ALARM";
		BrokerHosts brokerHosts = new ZkHosts(zks);
		SpoutConfig spoutConf = new SpoutConfig(brokerHosts, topic, zkRoot, id);
		spoutConf.scheme = new SchemeAsMultiScheme(new IMessahgeSchema());
		spoutConf.forceFromStart = false;
		spoutConf.zkServers = Arrays.asList(new String[] { "dev1", "dev2", "dev3" });
		spoutConf.zkPort = 2181;

		TopologyBuilder builder = new TopologyBuilder();
		builder.setSpout("alarm-kafka-consumer", new KafkaSpout(spoutConf), 3);
		builder.setBolt("AlarmParserBolt", new AlarmParserBolt(), 10).shuffleGrouping("alarm-kafka-consumer");
		builder.setBolt("GpsParserBolt", new GpsParserBolt(), 10).shuffleGrouping(
				"AlarmParserBolt");
		Config conf = new Config();
		if (StringUtil.isEmpty(nimbusHost)) {// debug model
			conf.setMaxTaskParallelism(3);
			LocalCluster cluster = new LocalCluster();
			cluster.submitTopology(topoName, conf, builder.createTopology());
			/*try {
				//Thread.sleep(60000);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
			}
			//cluster.shutdown();
*/
		} else {
			conf.put(Config.NIMBUS_HOST, nimbusHost);
			conf.setNumWorkers(3);
			try {
				StormSubmitter.submitTopologyWithProgressBar(topoName, conf, builder.createTopology());
			} catch (AlreadyAliveException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidTopologyException e) {
				logger.error(e.getMessage(), e);
			}

		}
	}

}
