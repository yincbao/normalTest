package com.hoperun.c4d.dao;

import java.io.File;
import java.util.List;

import com.hoperun.c4d.mongodb.AdaptedGridFile;

public interface IMFileDao {

	void save(AdaptedGridFile file);

	public <E extends AdaptedGridFile> boolean delete(Class<E> fileType,String fileName);

	public  <E extends AdaptedGridFile> List<File> find(Class<E> fileType,String fileName, boolean fuzzy,String outputFolder);
}
