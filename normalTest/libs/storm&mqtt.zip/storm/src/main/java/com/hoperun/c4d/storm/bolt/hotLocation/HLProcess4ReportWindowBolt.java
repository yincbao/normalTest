package com.hoperun.c4d.storm.bolt.hotLocation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;

import com.hoperun.c4d.bean.etc.ReaptCounter;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.bean.vo.APIWrapper;
import com.hoperun.c4d.bean.vo.MqttMessage;
import com.hoperun.c4d.bean.vo.response.HLResponse;
import com.hoperun.c4d.common.constant.StormConstants;
import com.hoperun.c4d.mqtt.pool.AbstractPooledMqttClient;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.StormUtil;
/**
 * 
 * ClassName: HLProcess4ReportWindowBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class HLProcess4ReportWindowBolt extends AbstractBolt {

	private static final Log logger = LogFactory.getLog(HLProcess4ReportWindowBolt.class);
	private static final long serialVersionUID = 886149197481637894L;
	private int topN = 3;
	private List<ReaptCounter<OsmWays>> list;

	public HLProcess4ReportWindowBolt(int topN) {
		this.topN = topN;
	}
	@Override
	public void prepare(@SuppressWarnings("rawtypes") Map arg0, TopologyContext arg1, OutputCollector arg2) {
		super.prepare(arg0, arg1, arg2);
		this.list = new CopyOnWriteArrayList<ReaptCounter<OsmWays>>();
	}

	public void cleanup() {
		list  = null;
	}

	public void execute(Tuple paramTuple) {

		try {
			Long lastWindowTime = paramTuple.getLong(2);
			ReaptCounter<OsmWays> hlCounter = (ReaptCounter<OsmWays>) paramTuple.getValueByField("hlCounter");
			list.add(hlCounter);
			long currentTime = System.currentTimeMillis();
			if (lastWindowTime == null || currentTime >= lastWindowTime + 3000) {
				List<ReaptCounter<OsmWays>> temp = new ArrayList<ReaptCounter<OsmWays>>();
				temp.addAll(list);
				APIWrapper api = APIWrapper.build(new HLResponse(groupResult(temp)));
				AbstractPooledMqttClient MqttClient = (AbstractPooledMqttClient) applicationContext.getBean("mqttClient");
				MqttClient.publishToAll(StormConstants.MQTT_TOPIC_FUNCTION_HL_, new MqttMessage(api.getSession(),api.toString()) , 2, true);
			}
			collector.ack(paramTuple);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			collector.fail(paramTuple);
		}
	}

	private List<ReaptCounter<OsmWays>> groupResult(List<ReaptCounter<OsmWays>> count) {
		Collections.sort(count);
		List<ReaptCounter<OsmWays>> temp = dropDuplicate(count);
		List<ReaptCounter<OsmWays>> result = new ArrayList<ReaptCounter<OsmWays>>();
		int loop = this.topN;
		if (count.size() <= loop)
			result.addAll(temp);
		else
			result.addAll(temp.subList(0, loop - 1));
		return result;
	}


	private List<ReaptCounter<OsmWays>> dropDuplicate(List<ReaptCounter<OsmWays>> count) {
		if(!StormUtil.isEmptyCollection(count)){
			List<ReaptCounter<OsmWays>> temp = new ArrayList<ReaptCounter<OsmWays>>();
			for(ReaptCounter<OsmWays> ele:count){
				if(!temp.contains(ele))
					temp.add(ele);
			}
			return temp;
		}
		return null;
		
	}
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session", "node"));
	}

	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
