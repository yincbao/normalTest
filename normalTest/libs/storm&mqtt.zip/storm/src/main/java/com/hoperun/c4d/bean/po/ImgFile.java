package com.hoperun.c4d.bean.po;

import java.io.File;

import com.hoperun.c4d.mongodb.AdaptedGridFile;
import com.hoperun.c4d.mongodb.Mongo;

@Mongo(database = "file_resc", collection = "", bucket = "images")
public class ImgFile extends AdaptedGridFile {

	public ImgFile(File file) {
		super(file);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 7290913937507207310L;
	
}
