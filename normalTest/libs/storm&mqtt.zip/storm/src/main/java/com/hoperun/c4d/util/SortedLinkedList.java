package com.hoperun.c4d.util;



/**
 * 
 * ClassName: SortedList
 * @description
 * @author yin_changbao
 * @Date   Jan 13, 2016
 * 
 * @param <E>
 */
public class SortedLinkedList<E extends java.lang.Comparable<E>> implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean asc = true;
	private int size;
	private int counter=0;

	public SortedLinkedList(int size,boolean asc) {
		super();
		this.size = size;
		this.asc = asc;
	}

	private class Data implements java.io.Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private E obj;
		private Data next = null;
		
		Data(E obj){
			this.obj = obj;
		}
	}

	private Data first = null;
	
	public void insert(E obj){
		if(size!=0&&counter==size)
			try {
				offer();
			} catch (Exception e) {
			}
		Data data = new Data(obj);
		Data pre = null;
		Data cur = first;
		if(asc){
			while(cur != null && data.obj.compareTo(cur.obj)>0){
				pre = cur;
				cur = cur.next;
			}
		}else{
			while(cur != null && data.obj.compareTo(cur.obj)<0){
				pre = cur;
				cur = cur.next;
			}
		}
		
		if(pre == null)
			first = data;
		else
			pre.next = data;
		data.next = cur;
		this.counter+=1;
	}
	
	public E offer() throws Exception{
		if(first == null)
			throw new Exception("empty!");
		Data temp = first;
		first = first.next;
		return temp.obj;
	}
	
	
	public int size(){
		return this.counter;
	}
	public String print(){
		if(first == null)
			return "[]";
		Data cur = first;
		StringBuilder sb = new StringBuilder("[");
		while(cur != null){
			sb.append(cur.obj.toString()).append("-> ");
			cur = cur.next;
		}
		sb.append("]");
		return sb.toString();
	}
	
	public E motsLikely(E e){
		Data cur = first;
		int chaju = Integer.MAX_VALUE;
		E re = null;
		while(cur != null){
			int echaju = Math.abs(cur.obj.compareTo(e));
			if(echaju==0)
				return cur.obj;
			else if(echaju<chaju){
				re = cur.obj;
				chaju = echaju;
				cur = cur.next;
			}else
				cur = cur.next;
			
		}
		return re;
	}
	
	
}