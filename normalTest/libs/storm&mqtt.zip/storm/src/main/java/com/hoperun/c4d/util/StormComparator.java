package com.hoperun.c4d.util;

import java.util.Comparator;

public class StormComparator implements Comparator<Object>{
	
	

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
