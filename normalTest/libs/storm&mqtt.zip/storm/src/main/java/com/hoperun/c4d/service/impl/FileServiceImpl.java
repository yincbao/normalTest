package com.hoperun.c4d.service.impl;

import java.io.File;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hoperun.c4d.bean.po.ImgFile;
import com.hoperun.c4d.dao.IMFileDao;
import com.hoperun.c4d.mongodb.AdaptedGridFile;
import com.hoperun.c4d.service.IFileService;

@Service("fileService")
public class FileServiceImpl implements IFileService{

	private static final Log logger = LogFactory.getLog(FileServiceImpl.class);
	@Autowired
	protected IMFileDao mFileDao;
	@Override
	public void saveImg(String filePath){
		
		AdaptedGridFile file = new ImgFile(new File(filePath)); 
		if(file.getFileSuffix().equalsIgnoreCase("img"))
			mFileDao.save(file);
		else
			logger.debug("file suffix is not img");
	}
	
	@Override
	public void delImg(String fileName){
		
		mFileDao.delete(ImgFile.class, fileName);
		
	}
	
	@Override
	public List<File> queryImg(String fileName,String output){
		
		return mFileDao.find(ImgFile.class, fileName, true,output);
		
	}
}
