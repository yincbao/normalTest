package com.hoperun.c4d.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.hoperun.c4d.bean.po.OsmHighWayMaxSpeed;
import com.hoperun.c4d.dao.DaoSupport;
import com.hoperun.c4d.dao.IOsmDefaultHighwayMaxSpeedDao;
import com.hoperun.c4d.util.StringUtil;
@Repository
public class OsmDefaultHighwayMaxSpeedDaoImpl  extends DaoSupport implements IOsmDefaultHighwayMaxSpeedDao{

	
	private static final Log logger  = LogFactory.getLog(OsmDefaultHighwayMaxSpeedDaoImpl.class);
	
	public List<OsmHighWayMaxSpeed> queryDefaultMaxSpeedByCondition(OsmHighWayMaxSpeed condition) {
		if(condition==null||StringUtil.isEmpty(condition.getHighway())){
			logger.debug("Error, conditon  at least  shohuld contain highway");
			return null;
		}
		StringBuffer hql = new StringBuffer("from OsmHighWayMaxSpeed where highway=? ");
		List<Object> param = new ArrayList<Object>();
		param.add(condition.getHighway());
		if(!StringUtil.isEmpty(condition.getCountry())){
			hql.append(" and country=? ");
			param.add(condition.getCountry().trim());
		}
			
		/*if(!StringUtil.isEmpty(condition.getDistrict())){
			hql.append(" and district=? ");
			param.add(condition.getDistrict().trim());
		}*/
		try {
			return this.queryByHql(hql.toString(), param.toArray());
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return null;
	}

}
