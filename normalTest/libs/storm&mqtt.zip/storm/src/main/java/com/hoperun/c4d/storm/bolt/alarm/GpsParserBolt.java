package com.hoperun.c4d.storm.bolt.alarm;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;

import com.hoperun.c4d.bean.po.AlarmData;
import com.hoperun.c4d.bean.po.GpsData;
import com.hoperun.c4d.bean.vo.APIWrapper;
import com.hoperun.c4d.bean.vo.MqttMessage;
import com.hoperun.c4d.bean.vo.response.AlarmResponse;
import com.hoperun.c4d.common.constant.StormConstants;
import com.hoperun.c4d.mqtt.pool.AbstractPooledMqttClient;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.CastelObdUtil;
@SuppressWarnings("unchecked")
public class GpsParserBolt extends AbstractBolt{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5803982162559993769L;

	private static final Log logger = LogFactory.getLog(GpsParserBolt.class);
	
	@Override
	public void execute(Tuple tuple) {
		List<GpsData> gps = CastelObdUtil.toGpsData((String[])tuple.getValue(1));
		logger.debug("parse gps data results:["+gps+"]");
		collector.ack(tuple);
		AbstractPooledMqttClient MqttClient = (AbstractPooledMqttClient) applicationContext.getBean("mqttClient");
		APIWrapper api = APIWrapper.build(new AlarmResponse(tuple.getString(0),(List<AlarmData>) tuple.getValue(2),gps));
		try {
			MqttClient.publishToAll(StormConstants.MQTT_TOPIC_FUNCTION_ALARM_, new MqttMessage(api.getSession(),api.toString()),  1, true);
		} catch (MqttPersistenceException e) {
			logger.error(e.getMessage(),e);
		} catch (MqttException e) {
			logger.error(e.getMessage(),e);
		}
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session","gps","alarm"));
		
	}

}
