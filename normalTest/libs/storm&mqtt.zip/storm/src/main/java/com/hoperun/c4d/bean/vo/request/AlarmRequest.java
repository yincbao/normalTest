package com.hoperun.c4d.bean.vo.request;

import java.util.Arrays;

import com.hoperun.c4d.common.constant.Topics;
import com.hoperun.exception.ExceptionCodeEnum;
import com.hoperun.exception.InterfaceException;
import com.hoperun.ubi.cache.util.StringUtil;

public class AlarmRequest implements IRequest{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2463451727649656529L;

	private String session;
	
	private String[] alarm;
	
	private String[] gps;
	
	private long time;
	
	
	
	
	

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public String[] getAlarm() {
		return alarm;
	}

	public void setAlarm(String[] alarm) {
		this.alarm = alarm;
	}

	public String[] getGps() {
		return gps;
	}

	public void setGps(String[] gps) {
		this.gps = gps;
	}

	public void setSession(String session) {
		this.session = session;
	}

	@Override
	public String getSession() {
		return this.session;
	}

	@Override
	public void validate() throws InterfaceException {
		if(StringUtil.isEmpty(session))
			throw new InterfaceException(ExceptionCodeEnum.INTERFACE_EXCEPTION_NO_SESSION_SPECIFIED);
	}

	@Override
	public String toString() {
		return "AlarmRequest [session=" + session + ", alarm=" + Arrays.toString(alarm) + ", gps="
				+ Arrays.toString(gps) + ", time=" + time + "]";
	}

	@Override
	public String getMessagePath() {
		return "";
	}


	@Override
	public String topicName() {
		return Topics.ALARM_MESSAGE_NOTIFICATION;
	}

}
