package com.hoperun.c4d.util;

import java.util.ArrayList;
import java.util.List;

import com.hoperun.c4d.bean.po.AlarmData;
import com.hoperun.c4d.bean.po.GpsData;

public final class CastelObdUtil {
	
	
	public static List<AlarmData> parseAlarmData(String[] target, long time) {
		List<AlarmData> list = null;
		if(target!=null){
			list = new ArrayList<AlarmData>();
			list.add(new AlarmData(time,target[0],Double.parseDouble(target[1]),Double.parseDouble(target[2])));
		}
		return list;
	}

	public static List<GpsData> toGpsData(String[] value) {
		List<GpsData> list = null;
		if(value!=null){
			list = new ArrayList<GpsData>();
			list.add(new GpsData(Long.parseLong(value[0]),Double.parseDouble(value[1]),Double.parseDouble(value[2]),Double.parseDouble(value[3])));
		}
		return list;
	}


}
