package com.hoperun.c4d.bean.vo.request;

import com.hoperun.c4d.bean.vo.IMessage;
import com.hoperun.exception.InterfaceException;

public interface IRequest extends IMessage{

	public String getSession();
	
	public void validate() throws InterfaceException;
}
