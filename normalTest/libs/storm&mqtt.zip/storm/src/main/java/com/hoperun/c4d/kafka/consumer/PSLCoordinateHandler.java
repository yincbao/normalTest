package com.hoperun.c4d.kafka.consumer;

import java.util.List;

import kafka.consumer.KafkaStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.etc.TupleValue;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.vo.request.PSLRequest;
import com.hoperun.c4d.kafka.consumer.handler.AbstractHandler;
import com.hoperun.c4d.service.IOsmNodesService;
import com.hoperun.c4d.util.StormUtil;
import com.hoperun.c4d.util.SystemConfig;
import com.hoperun.exception.InterfaceException;

public class PSLCoordinateHandler extends AbstractHandler<PSLRequest>{
	
	private static final Log logger = LogFactory.getLog(PSLCoordinateHandler.class);
	
	private static final Double defaultRange = SystemConfig.getDoubleProperty("ubi.psl.range.default", 0.8);

	
	private IOsmNodesService osmNodesService;
	
	public PSLCoordinateHandler(KafkaStream<byte[], byte[]> stream) {
		super(stream);
	}

	@Override
	public TupleValue handle(PSLRequest pslRequest) {
		try{
			pslRequest.validate();
			pslRequest.getCoordinate();
			List<OsmNodes> nodes = osmNodesService.findNearestNodes(pslRequest.getCoordinate().getLongitude(), pslRequest.getCoordinate().getLatitude(), defaultRange);
			return new TupleValue(new Values(nodes),StormUtil.globalUUID(),true);
		}catch(InterfaceException ie){
			logger.error(ie.getMessage(),ie);
			return new TupleValue(false);
		}
	}

	@Override
	public boolean doResponse(PSLRequest request) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
