package com.hoperun.c4d.kafka.consumer.handler;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.concurrent.Callable;

import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoperun.c4d.bean.etc.TupleValue;
import com.hoperun.c4d.bean.vo.IMessage;


public abstract class AbstractHandler<T extends IMessage > implements Callable<TupleValue> {

	private static final Log logger = LogFactory.getLog(AbstractHandler.class);

	protected KafkaStream<byte[], byte[]> stream;

	/**
	 * mostly suppose to do save or update to data persistence layer
	 * 
	 * @param request
	 * @return
	 */
	public abstract TupleValue handle(T request);

	/**
	 * do response to client, as required
	 * 
	 * @param originDataPackage
	 * @return
	 */

	public abstract boolean doResponse(T request);


	public AbstractHandler(KafkaStream<byte[], byte[]> stream) {
		super();
		this.stream = stream;
	}


	public final TupleValue call() throws Exception {
		ConsumerIterator<byte[], byte[]> it = stream.iterator();
		while (it.hasNext()) {
			byte[] b = it.next().message();
			ByteArrayInputStream bas = new ByteArrayInputStream(b);
			try {

				IMessage request = (IMessage) new ObjectInputStream(bas).readObject();
				doResponse((T)request);// response to obd client
				return handle((T)request);// mostly do save or update to DB
			} catch (ClassNotFoundException e) {
				logger.error("", e);
			} catch (Exception e) {
				logger.error("", e);
			}
		}
		return null;
	}
}
