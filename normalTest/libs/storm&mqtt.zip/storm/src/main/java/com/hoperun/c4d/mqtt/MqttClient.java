package com.hoperun.c4d.mqtt;

import java.io.File;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClientPersistence;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

import com.hoperun.c4d.util.StormUtil;
import com.hoperun.c4d.util.SystemConfig;
import com.hoperun.exception.ExceptionCodeEnum;
import com.hoperun.exception.NetworkException;

/**
 * 
 * ClassName: MqttClient
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class MqttClient implements IMqttClient {

	private static final Log logger = LogFactory.getLog(MqttClient.class);
	
	
	private String host = SystemConfig.getProperty("storm.mqtt.server","tcp://10.20.71.161:61613");
	private String userName = SystemConfig.getProperty("storm.mqtt.userName","admin");
	private String password = SystemConfig.getProperty("storm.mqtt.passwd","password");
	private String clientId = SystemConfig.getProperty("storm.mqtt.clientId","Server1");
	
	private int connectionTimeout = SystemConfig.getIntProperty("storm.mqtt.connection.timeout.seconds",30);
	private int keepAliveInterval = SystemConfig.getIntProperty("storm.mqtt.connection.keepAliveInterval.seconds",10);
	private boolean cleanSession = SystemConfig.getBooleanProperty("storm.mqtt.session.clean", false);
	private boolean useMemoryPersistence = SystemConfig.getBooleanProperty("storm.mqtt.data.Persistence.useMemory", false);
	private String dataDir = SystemConfig.getProperty("storm.mqtt.data.Persistence.dir", System.getProperty("user.dir"));

	// private String myTopic = "module/function/#";
	StormMqttClient client;

	public MqttClient(String host, String userName, String password, String clientId, int connectionTimeout,
			int keepAliveInterval, boolean cleanSession, boolean useMemoryPersistence, String dataDir) {
		super();
		this.host = host;
		this.userName = userName;
		this.password = password;
		this.clientId = clientId;
		this.connectionTimeout = connectionTimeout;
		this.keepAliveInterval = keepAliveInterval;
		this.cleanSession = cleanSession;
		this.useMemoryPersistence = useMemoryPersistence;
		this.dataDir = dataDir;
	}

	public MqttClient() {
		try {
			MqttClientPersistence persistence = null;
			if (useMemoryPersistence)
				persistence = new MemoryPersistence();
			else{
				dataDir+="/"+89999999*Math.random()+10000000+"/";
				File f = new File(dataDir);
				f.mkdirs();
				persistence = new MqttDefaultFilePersistence(dataDir);
			}
				
			client = new StormMqttClient(host, clientId, persistence);
			connect();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override@Deprecated
	public void publish(String topic, IMqttMessage message) {
		try {
			client.publish(topic, new MqttMessage(message.getBytes()));
		} catch (MqttPersistenceException e) {
			logger.error(e.getMessage());
		} catch (MqttException e) {
			logger.error(e.getMessage());
		}
	}

	@Override
	public MqttDeliveryToken publish(String topic, IMqttMessage msg,int oos,boolean retained) throws MqttPersistenceException, MqttException {
		MqttTopic topicObj = client.getTopic(topic,true);
		MqttMessage message = new MqttMessage();
		message.setQos(oos);
		message.setRetained(retained);
		message.setPayload(msg.getBytes());
		MqttDeliveryToken token = topicObj.publish(message);
		token.waitForCompletion();
		token.isComplete();
		logger.debug(String.format("sucessfully publish msg[%s] of topic [%s] with oos [%d]  ", msg,topic,oos));
		return token;
	}

	@Override
	public void subscribe(String... topic) {
		if(topic==null||topic.length==0)
			throw new NetworkException(ExceptionCodeEnum.NETWORK_EMPTY_MQTT_TOPIC);
		 try {
			client.subscribe(topic);
		} catch (MqttException e) {
			logger.error(e.getMessage(),e);
		}
	}

	@Override
	public void subscribe(Map<String, Integer> topicAndOos) {
		if(StormUtil.isEmptyMap(topicAndOos))
			throw new NetworkException(ExceptionCodeEnum.NETWORK_EMPTY_MQTT_TOPIC);
		try {
			int count = topicAndOos.keySet().size();
			String[] topics = new String[count];
			int[] oos = new int[count];
			int idx = 0;
			for(Map.Entry<String, Integer> entry : topicAndOos.entrySet()){
				topics[idx] = entry.getKey();
				oos[idx] = entry.getValue();
			}
			client.subscribe(topics,oos);
		} catch (MqttException e) {
			logger.error(e.getMessage(),e);
		}
		
	}

	@Override
	public void unsubscribe(String... topic) {
		if(topic==null||topic.length==0)
			throw new NetworkException(ExceptionCodeEnum.NETWORK_EMPTY_MQTT_TOPIC);
		try {
			client.unsubscribe(topic);
		} catch (MqttException e) {
			logger.error(e.getMessage(),e);
		}
		
	}

	@Override
	public void close(boolean forcibly, Long quiesceTimeout) {
		if(quiesceTimeout==null||quiesceTimeout.longValue()<0)
			quiesceTimeout = null;
		if(client==null)
			return;
		try{
			if(forcibly)
				client.disconnectForcibly(quiesceTimeout);
			else
				client.disconnect(quiesceTimeout);
			
			client.close();
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		
	}

	private void connect() {
		MqttConnectOptions options = new MqttConnectOptions();
		options.setCleanSession(cleanSession);
		options.setUserName(userName);
		options.setPassword(password.toCharArray());
		options.setConnectionTimeout(connectionTimeout);
		options.setKeepAliveInterval(keepAliveInterval);
		try {
			client.setCallback(new MqttCallback() {
				public void connectionLost(Throwable cause) {
					logger.error("mqtt connection lost", cause);
				}
	
				public void deliveryComplete(IMqttDeliveryToken token) {
					logger.debug("is delivery succeddfully operated: " + token.isComplete());
				}
	
				public void messageArrived(String topic, MqttMessage arg1) throws Exception {
					if (arg1 != null) {
						logger.debug(String.format("client #[%s] gets a message[%s] of topic [%s] ", clientId,
								arg1.toString(), topic));
					}
				}
	
			});
			client.connect(options);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	
	}
}
