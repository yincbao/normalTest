package com.hoperun.c4d.kafka.producer;

import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import kafka.serializer.StringEncoder;

import com.hoperun.c4d.bean.vo.IMessage;
import com.hoperun.c4d.kafka.producer.serializer.OcsJdkSerializer;
import com.hoperun.c4d.util.StringUtil;
import com.hoperun.c4d.util.SystemConfig;
/**
 * 
 * ClassName: Sink
 * @description
 * @author yin_changbao
 * @Date   Oct 29, 2015
 *
 */
public class Sink {
	
	static Producer<String,IMessage> producer = null;
	
	static{
		String brokers = SystemConfig.getProperty("acc.mq.kafka.brokers");
		Properties parameters = new Properties();
		parameters.put("metadata.broker.list", brokers);
		//TODO define a json formarted serializer which can be applied into kafka
		parameters.put("serializer.class", OcsJdkSerializer.class.getName());
		parameters.put("key.serializer.class", "kafka.serializer.StringEncoder");
		//parameters.put("partitioner.class", "");
		parameters.put("request.required.acks", "1");
		producer = new Producer<String,IMessage>( new ProducerConfig(parameters));
	}
	
	
	public static void send(String topic,IMessage message){
		send( topic, null, message);
	}
	
	
	public static void send(String topic,String partition,IMessage message){
		KeyedMessage<String, IMessage> data = (StringUtil.isEmpty(partition)) ? new KeyedMessage<String, IMessage>(topic,message) : new KeyedMessage<String, IMessage>(topic, partition, message);
		producer.send(data);
	}
	
	public static void sendStr(String topic,String partition,String message){
		KeyedMessage<String, String> data = (StringUtil.isEmpty(partition)) ? new KeyedMessage<String, String>(topic,message) : new KeyedMessage<String, String>(topic, partition, message);
		
		String brokers = SystemConfig.getProperty("acc.mq.kafka.brokers");
		Properties parameters = new Properties();
		parameters.put("metadata.broker.list", brokers);
		//TODO define a json formarted serializer which can be applied into kafka
		parameters.put("serializer.class", StringEncoder.class.getName());
		parameters.put("key.serializer.class", "kafka.serializer.StringEncoder");
		//parameters.put("partitioner.class", "");
		parameters.put("request.required.acks", "1");
		Producer<String,String> producer = new Producer<String,String>( new ProducerConfig(parameters));
		producer.send(data);
	}
	
	
}
