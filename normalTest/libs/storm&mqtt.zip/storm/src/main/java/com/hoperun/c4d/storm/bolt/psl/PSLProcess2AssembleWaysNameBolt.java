package com.hoperun.c4d.storm.bolt.psl;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.Coordinate;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
/**
 * 
 * ClassName: PSLProcess2AssembleWaysNameBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class PSLProcess2AssembleWaysNameBolt extends AbstractBolt{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2978369150656562078L;
	private OutputCollector collector;
	private static final Log logger = LogFactory.getLog(PSLProcess2AssembleWaysNameBolt.class);
	
	
	@Override
	public void execute(Tuple paramTuple) {
		OsmNodes node = (OsmNodes) paramTuple.getValue(2);
		List<OsmWays> wayList = (List<OsmWays>) paramTuple.getValue(3);
		Coordinate coor = (Coordinate) paramTuple.getValue(4);
		try{
			IOsmWaysService omsWaysService = applicationContext.getBean(IOsmWaysService.class);
			collector.emit(new Values(paramTuple.getString(0),paramTuple.getInteger(1),node,wayList,omsWaysService.assembleWaysName(coor.getLongitude(), coor.getLatitude())));
			collector.ack(paramTuple);
		}catch(Exception e){
			logger.error("error occurred, will fail this tuple",e);
			collector.fail(paramTuple);
		}
		
	}

	@Override
	public void cleanup() {
		//nothing to do, no resource to release
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session","nodeSize","nodesStr","waysStr","district"));
	}

	@Override
	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
