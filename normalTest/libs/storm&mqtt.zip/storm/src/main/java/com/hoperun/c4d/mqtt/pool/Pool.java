package com.hoperun.c4d.mqtt.pool;

import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.impl.GenericObjectPool;

import com.hoperun.c4d.mqtt.IMqttClient;

/**
 * 
 * ClassName: Pool
 * @description
 * @author yin_changbao
 * @Date   Jan 29, 2016
 *
 */
public class Pool extends GenericObjectPool<IMqttClient> {
	
	public Pool(BasePooledObjectFactory<IMqttClient> factory, Config config) {
		super(factory, config);
	}
}
