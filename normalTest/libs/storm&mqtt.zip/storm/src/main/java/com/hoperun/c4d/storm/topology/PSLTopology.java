package com.hoperun.c4d.storm.topology;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import storm.kafka.BrokerHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import storm.kafka.ZkHosts;
import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.spout.SchemeAsMultiScheme;
import backtype.storm.topology.TopologyBuilder;

import com.hoperun.c4d.common.constant.Topics;
import com.hoperun.c4d.storm.bolt.psl.PSLProcess1NodeWayLinkerBolt;
import com.hoperun.c4d.storm.bolt.psl.PSLProcess2AssembleWaysNameBolt;
import com.hoperun.c4d.storm.bolt.psl.PSLProcess3AssembleWaysMaxSpeedBolt;
import com.hoperun.c4d.storm.bolt.psl.PSLProcess4AssembleNodesWayIdBolt;
import com.hoperun.c4d.storm.bolt.psl.PSLProcess5MergeBolt;
import com.hoperun.c4d.storm.scheme.IMessahgeSchema;
import com.hoperun.ubi.cache.util.StringUtil;

public class PSLTopology {

	private static final Log logger = LogFactory.getLog(PSLTopology.class);

	public static void publish(String nimbusHost) {
		/********kafka consumer config*****/
		String topoName = "PSL";
		String zks = "dev1:2181,dev2:2181,dev3:2181";
		String topic = Topics.PSL_NODES_SECTION;
		String zkRoot = "/storm"; // default zookeeper root configuration for
		String id = "psl";//msgId, as was said KafkaSpout is reliable spout
		BrokerHosts brokerHosts = new ZkHosts(zks);
		SpoutConfig spoutConf = new SpoutConfig(brokerHosts, topic, zkRoot, id);
		spoutConf.scheme = new SchemeAsMultiScheme(new IMessahgeSchema());
		spoutConf.forceFromStart = false;
		spoutConf.zkServers = Arrays.asList(new String[] { "dev1", "dev2", "dev3" });
		spoutConf.zkPort = 2181;
		/********kafka consumer config end *****/
		
		TopologyBuilder builder = new TopologyBuilder();
		//kafkao consumer
		builder.setSpout("kafka-consumer", new KafkaSpout(spoutConf), 1);//executer Name is "kafka-consumer" Spout is new KafkaSpout(spoutConf) and 1 is  parallelism number, here is one thread only
		
		builder.setBolt("node-way-linkin", new PSLProcess1NodeWayLinkerBolt(), 10).shuffleGrouping("kafka-consumer");//Bolt config: shuffleGrouping as mentioned, is stream gourp way
		
		builder.setBolt("way-name-assemble", new PSLProcess2AssembleWaysNameBolt(), 10).shuffleGrouping(
				"node-way-linkin");
		builder.setBolt("way-maxSpeed-assemble", new PSLProcess3AssembleWaysMaxSpeedBolt(), 10).shuffleGrouping(
				"way-name-assemble");
		builder.setBolt("node-wayId-assemble", new PSLProcess4AssembleNodesWayIdBolt(), 10).shuffleGrouping(
				"way-maxSpeed-assemble");
		builder.setBolt("merge", new PSLProcess5MergeBolt(),1).globalGrouping("node-wayId-assemble");

		Config conf = new Config();
		if (StringUtil.isEmpty(nimbusHost)) {// debug model
			conf.setMaxTaskParallelism(3);
			LocalCluster cluster = new LocalCluster();
			cluster.submitTopology(topoName, conf, builder.createTopology());
			//just for debug model, won't shutdown localCluster
		} else {
			conf.put(Config.NIMBUS_HOST, nimbusHost);
			conf.setNumWorkers(3);
			try {
				StormSubmitter.submitTopologyWithProgressBar(topoName, conf, builder.createTopology());
			} catch (AlreadyAliveException e) {
				logger.error(e.getMessage(), e);
			} catch (InvalidTopologyException e) {
				logger.error(e.getMessage(), e);
			}

		}
	}

}
