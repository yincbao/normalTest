package com.hoperun.c4d.bean.po;

import java.io.Serializable;

public class AlarmData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8603708431991149468L;
	
	private long time;

	private String alarmType;
	
	private Double alarmDesc;
	
	private Double alarmThreshold;

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public String getAlarmType() {
		return alarmType;
	}

	public void setAlarmType(String alarmType) {
		this.alarmType = alarmType;
	}

	public Double getAlarmDesc() {
		return alarmDesc;
	}

	public void setAlarmDesc(Double alarmDesc) {
		this.alarmDesc = alarmDesc;
	}

	public Double getAlarmThreshold() {
		return alarmThreshold;
	}

	public void setAlarmThreshold(Double alarmThreshold) {
		this.alarmThreshold = alarmThreshold;
	}


	public AlarmData(long time, String alarmType, Double alarmDesc, Double alarmThreshold) {
		super();
		this.time = time;
		this.alarmType = alarmType;
		this.alarmDesc = alarmDesc;
		this.alarmThreshold = alarmThreshold;
	}

	public AlarmData(long time) {
		super();
		this.time = time;
	}

	public AlarmData() {
		super();
	}

	@Override
	public String toString() {
		return "AlarmData [time=" + time + ", alarmType=" + alarmType + ", alarmDesc=" + alarmDesc
				+ ", alarmThreshold=" + alarmThreshold + "]";
	}
}
