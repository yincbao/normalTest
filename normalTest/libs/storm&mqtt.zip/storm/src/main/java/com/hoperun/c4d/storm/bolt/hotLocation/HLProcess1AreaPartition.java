package com.hoperun.c4d.storm.bolt.hotLocation;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.vo.request.HLRequest;
import com.hoperun.c4d.service.IOsmNodesService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
/**
 * 
 * ClassName: HLProcess1AreaPartition
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class HLProcess1AreaPartition extends AbstractBolt {

	private static final Log logger = LogFactory.getLog(HLProcess1AreaPartition.class);
	private static final long serialVersionUID = 886149197481637894L;

	public void cleanup() {
	}

	public void execute(Tuple paramTuple) {
		
		try{
			IOsmNodesService osmNodesService = applicationContext.getBean(IOsmNodesService.class);
			
			HLRequest message = (HLRequest) paramTuple.getValues().get(0);
			OsmNodes node = osmNodesService.findNearestNode(message.getCoordinate().getLongitude(), message.getCoordinate().getLatitude(), 50*0.001);
			collector.emit(new Values(node));
			collector.ack(paramTuple);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
			collector.fail(paramTuple);
		}
		
	}


	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("nodeIn1"));
	}

	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
