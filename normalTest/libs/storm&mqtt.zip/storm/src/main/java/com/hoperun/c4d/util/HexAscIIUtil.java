package com.hoperun.c4d.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ArrayUtils;

public final class HexAscIIUtil {

	static Pattern ipPartten = Pattern.compile(".* (\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})");

	/**
	 * 
	 * @param num
	 * @return
	 */
	public static byte int2OneByte(int num) {
		return (byte) (num & 0x000000ff);
	}

	public static byte[] int2Bytes(int num) {
		return int2Bytes(num,false); 
	}
	
	public static byte[] int2Bytes(int num,boolean isLH) {
		byte[] byteNum = new byte[4];
		for (int ix = 0; ix < 4; ++ix) {
			int offset = 32 - (ix + 1) * 8;
			byteNum[ix] = (byte) ((num >> offset) & 0xff);
		}
		if (isLH)
			ArrayUtils.reverse(byteNum);
		return byteNum;
	}
	
	public static byte[] int2BytesDropHZero(int num,boolean isLH,int minLength) {
		minLength = minLength>=4?4:minLength;
		byte[] byteNum = new byte[4];
		int idx = 0;
		for (int ix = 0; ix < 4; ++ix) {
			int offset = 32 - (ix + 1) * 8;
			byte temp = (byte) ((num >> offset) & 0xff);
			if(temp>0){
				byteNum[idx]=temp;
				idx++;
			}
				
		}
		idx = minLength>idx?minLength:idx;
		if(idx<1&&minLength<1)
			return null;
		
		byte[] res = new byte[idx];
		for(int i=0;i<idx;i++)
			res[i]=byteNum[i];
		
		if (isLH)
			ArrayUtils.reverse(res);
		return res;
	}

	/**
	 * default low to high
	 * 
	 * @param number
	 * @return
	 */
	public static byte[] long2Bytes(long number) {
		long temp = number;
		byte[] b = new byte[8];
		for (int i = 0; i < b.length; i++) {
			b[i] = new Long(temp & 0xff).byteValue();
			temp = temp >> 8;
		}
		return b;
	}


	/**
	 * common transfer
	 * @param isLH
	 * @return
	 */
	public static byte[] getUTCTimeLong(boolean isLH) {

		Calendar calendar = Calendar.getInstance();
		int zoneOffset = calendar.get(java.util.Calendar.ZONE_OFFSET);
		int dstOffset = calendar.get(java.util.Calendar.DST_OFFSET);
		calendar.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset));
		byte[] utcByte = long2Bytes(calendar.getTimeInMillis() / 1000);// client

		byte[] result4Unix = new byte[4];
		System.arraycopy(utcByte, 0, result4Unix, 0, 4);
		if (isLH)
			ArrayUtils.reverse(result4Unix);
		return result4Unix;
	}
	
	public static byte[] getUTCFor213GL(){
		Calendar calendar = Calendar.getInstance();
		int zoneOffset = calendar.get(java.util.Calendar.ZONE_OFFSET);
		int dstOffset = calendar.get(java.util.Calendar.DST_OFFSET);
		calendar.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset));
		int year = calendar.get(Calendar.YEAR)-2000;
		year = year>255?255:year;
		int month = calendar.get(Calendar.MONTH)+1;
		int date = calendar.get(Calendar.DATE);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		return new byte[]{int2OneByte(year),int2OneByte(month),int2OneByte(date),int2OneByte(hour),int2OneByte(minute),int2OneByte(second)};
		
	}

	// 2013 -10-25- 12:17:05 yyyyMMddHHmmssSSS
	public static Date string2Date(String strDate, String format) {
		SimpleDateFormat dateFormater = new SimpleDateFormat(format);
		try {
			return dateFormater.parse(strDate);
		} catch (Exception e) {
			return new Date();
		}
	}

	public static int bytes2Int(byte[] src) {
		int value = 0;
		for (int i = 0; i < src.length; i++) {
			value |= (src[i] & 0xFF) << (i * 8);
		}
		return value;
	}

	public static int byte2Int(byte src) {
		return src & 0xFF;
	}

	public static byte[] ipValue2Byte(String ipStr){
		return long2Bytes(getIpValueV4Version(ipStr));
	}
	
	public static long getIpValueV4Version(String ip) {
        try {
            String[] ipSeq = ip.split("\\.");
            final int len = 4;
            if (ipSeq.length != len) {
                throw new IllegalArgumentException("is not ip");
            }

            int count = 0;
            final long l1 = 16777216;
            final long l2 = 65536;
            final long l3 = 256;
            return (Long.parseLong(ipSeq[count++]) * l1) + (Long.parseLong(ipSeq[count++]) * l2)
                    + (Long.parseLong(ipSeq[count++]) * l3) + (Long.parseLong(ipSeq[count++]));
        } catch (Exception e) {
            return 0L; 
        }
    }

}
