package com.hoperun.c4d.mqtt;


/**
 * 
 * ClassName: IMqttMessage
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public interface IMqttMessage extends  java.io.Serializable{
	
	public byte[] getBytes();
	
}
