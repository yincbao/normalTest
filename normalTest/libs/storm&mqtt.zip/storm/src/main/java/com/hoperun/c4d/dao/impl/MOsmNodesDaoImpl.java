package com.hoperun.c4d.dao.impl;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import com.hoperun.c4d.bean.etc.Page;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.dao.IMOsmNodesDao;
import com.hoperun.c4d.mongodb.DaoSupport;
import com.hoperun.c4d.util.StormUtil;
import com.mongodb.BasicDBObject;
/**
 * 
 * ClassName: MOsmNodesDaoImpl
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
@Repository
public class MOsmNodesDaoImpl extends DaoSupport<OsmNodes> implements IMOsmNodesDao{

	
	private static final Log logger = LogFactory.getLog(MOsmNodesDaoImpl.class);
	
	private static final Double defaultRange = 100.00D;

	/*
	 * (non-Javadoc)
	 * @see com.hoperun.ubi.persistence.mongo.IMOsmNodesDao#findNearestNode(java.lang.Double, java.lang.Double, java.lang.Double)
	 */
	public OsmNodes findNearestNode(Double longitude, Double latitude, Double maxDistance) {
		if(longitude==null||latitude==null){
			logger.debug("longitude latitude can't be null");
			return null;
		}
		if(longitude.longValue()==0&&latitude.longValue()==0){
			logger.debug("longitude latitude is (0,0) abandon");
			return null;
		}
		maxDistance = maxDistance==null?defaultRange:maxDistance;
		
		Map<String ,Object> mql = new IdentityHashMap<String ,Object>();
		mql.put("coordinate", new BasicDBObject("$nearSphere", new Double[]{longitude,latitude}).append("$maxDistance", maxDistance/6378.137));
		try{
			List<OsmNodes> result = this.queryLimit(mql,null,null, OsmNodes.class, 1);
			return StormUtil.isEmptyCollection(result)?null:result.get(0);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		return null;
	}
	
	public List<OsmNodes> findNearestNodes(Double longitude, Double latitude, Double maxDistance) {
		if(longitude==null||latitude==null){
			logger.debug("longitude latitude can't be null");
			return null;
		}
		if(longitude.longValue()==0&&latitude.longValue()==0){
			logger.debug("longitude latitude is (0,0) abandon");
			return null;
		}
		maxDistance = maxDistance==null?defaultRange:maxDistance;
		
		Map<String ,Object> mql = new IdentityHashMap<String ,Object>();
		mql.put("coordinate", new BasicDBObject("$nearSphere", new Double[]{longitude,latitude}).append("$maxDistance", maxDistance/6378.137));
		try{
			return  this.queryAll(mql,null, OsmNodes.class);
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		return null;
	}
	
	public Page<OsmNodes> pagingNearestNodes(Page<OsmNodes> page,Double longitude, Double latitude, Double maxDistance){
		if(longitude==null||latitude==null){
			logger.debug("longitude latitude can't be null");
			return null;
		}
		if(longitude.longValue()==0&&latitude.longValue()==0){
			logger.debug("longitude latitude is (0,0) abandon");
			return null;
		}
		if(page==null||(page.getLastIdx()==null&&page.getPageNo()>1))
			page = new Page<OsmNodes>(100,1);
		maxDistance = maxDistance==null?defaultRange:maxDistance;
		
		IdentityHashMap<String ,Object> mql = new IdentityHashMap<String ,Object>();
		mql.put("coordinate", new BasicDBObject("$nearSphere", new Double[]{longitude,latitude}).append("$maxDistance", maxDistance/6378.137));
		Map<String ,Integer> sort = new IdentityHashMap<String ,Integer>();
		sort.put("id", 1);
		try{
			Page<OsmNodes> rpage = this.paging(mql, null, sort, OsmNodes.class, page.getPageNo(), page.getPageSize(), page.getLastIdx());
			rpage.setLastIdx(rpage.getData().get(rpage.getData().size()-1).getId());
			return rpage;
		}catch(Exception e){
			logger.error(e.getMessage(),e);
		}
		return page;
	}
	
	
}
