package com.hoperun.c4d.storm.bolt.psl;

import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.service.IOsmWaysService;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
/**
 * 
 * ClassName: PSLProcess3AssembleWaysMaxSpeedBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class PSLProcess3AssembleWaysMaxSpeedBolt extends AbstractBolt{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6410316433689432401L;
	private static final Log logger = LogFactory.getLog(PSLProcess3AssembleWaysMaxSpeedBolt.class);
	
	@Override
	public void execute(Tuple paramTuple) {
		OsmNodes node = (OsmNodes) paramTuple.getValue(2);
		List<OsmWays> way = (List<OsmWays>) paramTuple.getValue(3);
		String[] district = (String[]) paramTuple.getValues().get(4);
		try{
			IOsmWaysService omsWaysService = applicationContext.getBean(IOsmWaysService.class);
			omsWaysService.assembleWaysMaxSpeed(way, district);
			collector.emit(new Values(paramTuple.getString(0),paramTuple.getInteger(1),node,way));
			collector.ack(paramTuple);
		}catch(Exception e){
			logger.error("error occurred, will fail this tuple",e);
			collector.fail(paramTuple);
		}
		
	}

	@Override
	public void cleanup() {
		
	}

	@Override
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session","nodeSize","nodesStr","waysStr"));
	}

	@Override
	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
