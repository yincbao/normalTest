package com.hoperun.c4d.bean.etc;

import backtype.storm.tuple.Values;

public class TupleValue {
	
	Values value;
	
	String messageId;
	
	boolean isReady;
	

	public boolean isReady() {
		return isReady;
	}

	public void setReady(boolean isReady) {
		this.isReady = isReady;
	}

	public Values getValue() {
		return value;
	}

	public void setValue(Values value) {
		this.value = value;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public TupleValue(Values value, String messageId,boolean isReady) {
		super();
		this.value = value;
		this.messageId = messageId;
		this.isReady = isReady;
	}

	public TupleValue(boolean isReady) {
		super();
		this.isReady = isReady;
	}
	
}
