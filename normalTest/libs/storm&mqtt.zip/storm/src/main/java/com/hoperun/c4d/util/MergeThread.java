package com.hoperun.c4d.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.bean.vo.APIWrapper;
import com.hoperun.c4d.bean.vo.MqttMessage;
import com.hoperun.c4d.bean.vo.response.PSLResponse;
import com.hoperun.c4d.common.constant.StormConstants;
import com.hoperun.c4d.mqtt.pool.AbstractPooledMqttClient;

public class MergeThread implements Callable<Boolean> {

	private static final Log logger = LogFactory.getLog(MergeThread.class);

	private final BlockingQueue<OsmNodes> nodeQueue = new ArrayBlockingQueue<OsmNodes>(5000);
	private final BlockingQueue<OsmWays> wayQueue = new ArrayBlockingQueue<OsmWays>(500);

	public String session;
	public int totalSize;
	private Map<String, List<OsmNodes>> sessionNodes = null;
	private Map<String, List<OsmWays>> sessionWays = null;
	
	private ApplicationContext applicationContext;


	public MergeThread(String session, int totalSize,final Map<String, List<OsmNodes>> sessionNodes,
			final Map<String, List<OsmWays>> sessionWays,ApplicationContext applicationContext) {
		super();
		this.session = session;
		this.totalSize = totalSize;
		this.sessionNodes = sessionNodes;
		this.sessionWays = sessionWays;
		this.applicationContext = applicationContext;
	}

	public void add(OsmNodes node, OsmWays way) {
		nodeQueue.add(node);
		wayQueue.add(way);
	}

	
	public boolean lost(int csize){
		double per = (totalSize-csize)/(double)totalSize;
		logger.info(String.format("lost percentage is [%d]%", per*100));
		if(per<=0.2)
			return true;
		else 
			return false;
	}
	@Override
	public Boolean call() throws Exception {
		
		for(int i=0;i<nodeQueue.size();i++) 
			try{
				merge(session, Arrays.asList(nodeQueue.take()), Arrays.asList(wayQueue.take()));
			}catch(Exception e){
				logger.error(e.getMessage(), e);
			}
			
		List<OsmNodes> nodeList = sessionNodes.get(session);
		List<OsmWays> wayList  = duplicate(sessionWays.get(session));
		String sessionId = session.split(StormConstants.SPLITOR)[0];
		int squence = Integer.parseInt(session.split(StormConstants.SPLITOR)[1].split("\\/")[0]);
		int total = Integer.parseInt(session.split(StormConstants.SPLITOR)[1].split("\\/")[1]);
		
		AbstractPooledMqttClient MqttClient = (AbstractPooledMqttClient) applicationContext.getBean("mqttClient");
		if (total == 1) {
			APIWrapper api = APIWrapper.build(new PSLResponse(session, nodeList, wayList));
			MqttClient.publishToClient(StormConstants.MQTT_TOPIC_FUNCTION_PSL_,"seeion_getClientId", new MqttMessage(api.getSession(),api.toString()), 1, true);
		} else {
			String nodesStr = JsonHelper.bean2Json(nodeList, true);
			String squencekey = CacheUtil.buildKey(StormConstants.CACHE_KEY_PREFIX_PSL_SESSION_SECTION_SEQUENCE,
					sessionId);
			String key = CacheUtil.buildKey(StormConstants.CACHE_KEY_PREFIX_PSL_SESSION_SECTION, sessionId);
			Map<String, List<OsmWays>> map = CacheUtil.tryCache(key, Map.class);
			map = map == null ? new HashMap<String, List<OsmWays>>() : map;
			map.put(nodesStr, wayList);
			Set<Integer> s = CacheUtil.tryCache(squencekey, HashSet.class);
			if (s == null || s.isEmpty()) {
				s = new HashSet<Integer>();
				s.add(squence);
				String st = JsonHelper.bean2Json(s);
				CacheUtil.updateCache(squencekey, s);
				CacheUtil.updateCache(key, map);
			} else if (s.size() + 1 == total) {// all bolt done

				Iterator<String> ite = map.keySet().iterator();
				List<OsmNodes> allNodes = new ArrayList<OsmNodes>();
				List<OsmWays> allWays = new ArrayList<OsmWays>();
				while (ite.hasNext()) {
					String nodes = ite.next();
					allNodes.addAll((List<OsmNodes>) JsonHelper.json2Bean(nodes, List.class, OsmNodes.class, true));
					allWays.addAll(map.get(nodes));
				}
				try {
					APIWrapper api = APIWrapper.build(new PSLResponse(session, allNodes, allWays));
					MqttClient.publishToClient(StormConstants.MQTT_TOPIC_FUNCTION_PSL_,"seeion_getClientId", new MqttMessage(api.getSession(),api.toString()), 1, true);
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					return false;
				}
				CacheUtil.removeCache(squencekey);
				CacheUtil.removeCache(key);
			}
		}
		return true;
	}

	private List<OsmWays> duplicate(List<OsmWays> list) {
		if(StormUtil.isEmptyCollection(list))
			return null;
		List<OsmWays> temp = new ArrayList<OsmWays>();
		for(OsmWays way:list){
			if(!temp.contains(way))
				temp.add(way);
		}
		return temp;
	}

	private int merge(String session, List<OsmNodes> nodeList, List<OsmWays> wayList) {
		saveOrUpdate(sessionWays, session, wayList);
		return saveOrUpdate(sessionNodes, session, nodeList);
	}

	private <E extends java.io.Serializable> int saveOrUpdate(Map<String, List<E>> sessionNodes, String session,
			List<E> elemList) {
		List<E> nodes = sessionNodes.get(session);
		nodes = nodes == null ? new ArrayList<E>() : nodes;
		if (!StormUtil.isEmptyCollection(elemList))
			nodes.addAll(elemList);
		sessionNodes.put(session, nodes);
		return nodes.size();

	}
}
