package com.hoperun.c4d.bean.po;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "psl_osm_highway_max_speed")
public class OsmHighWayMaxSpeed implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	private Long id;
	@Column(length = 128, nullable = true)
	private String country;
	@Column(length = 512, nullable = true)
	private String district;
	@Column(length = 512, nullable = true)
	private String highway;
	@Column
	private Double maxSpeed;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getHighway() {
		return highway;
	}
	public void setHighway(String highway) {
		this.highway = highway;
	}
	public Double getMaxSpeed() {
		return maxSpeed;
	}
	public void setMaxSpeed(Double maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

}
