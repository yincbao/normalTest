package com.hoperun.c4d.mqtt.pool;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

import com.hoperun.c4d.mqtt.IMqttClient;
import com.hoperun.c4d.mqtt.IMqttMessage;
import com.hoperun.ubi.cache.util.StringUtil;

/**
 * 
 * ClassName: AbstractPooledMqttClient
 * @description
 * @author yin_changbao
 * @Date   Jan 29, 2016
 *
 */
public abstract class AbstractPooledMqttClient {
	
	private static final Log logger = LogFactory.getLog(AbstractPooledMqttClient.class);

	public static final int DEFAULT_MAXTOTAL = 20;
	public static final int DEFAULT_MAXTOTALPERKEY = 5;
	public static final int DEFAULT_MINIDLEPERKEY = 0;

	public static final int DEFAULT_MAXWAITMILLIS = -1;
	protected Pool pool;
	
	public MqttDeliveryToken publishToAll(String topic,IMqttMessage message,int qos,boolean retained)throws MqttPersistenceException, MqttException{
		IMqttClient client;
		try {
			client = this.pool.borrowObject();
			if(!StringUtil.isEmpty(topic)){
				if(topic.lastIndexOf("\\#")>-1||topic.lastIndexOf("\\*")>-1)
					return client.publish(topic, message, qos, retained);
				else
					return client.publish(topic+"/#", message, qos, retained);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return null;
		
	} 
	
	public MqttDeliveryToken publishToClient(String topic,String clientId,IMqttMessage message,int qos,boolean retained)throws MqttPersistenceException, MqttException{
		IMqttClient client;
		try {
			client = this.pool.borrowObject();
			return client.publish(topic+"/"+clientId, message, qos, retained);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return null;
		
	}
	
	public void subscribe(String...topic){
		IMqttClient client;
		try {
			client = this.pool.borrowObject();
			client.subscribe(topic);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}
	
	public void subscribe(Map<String,Integer> topicAndOos){
		IMqttClient client;
		try {
			client = this.pool.borrowObject();
			client.subscribe(topicAndOos);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}
	
	
	public void unsubscribe(String...topic){
		IMqttClient client;
		try {
			client = this.pool.borrowObject();
			client.unsubscribe(topic);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}
	
	public void close(boolean forcibly,Long quiesceTimeout){
		IMqttClient client;
		try {
			client = this.pool.borrowObject();
			client.close(forcibly, quiesceTimeout);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}
}
