package com.hoperun.c4d.mongodb;
public class ISODateTime implements java.io.Serializable{
		
		/**
	 * 
	 */
	private static final long serialVersionUID = 2964391790845512136L;
		String $date;

		public String get$date() {
			return $date;
		}

		public void set$date(String $date) {
			this.$date = $date;
		}
	}