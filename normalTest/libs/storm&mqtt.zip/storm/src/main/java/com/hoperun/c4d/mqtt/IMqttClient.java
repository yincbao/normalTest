package com.hoperun.c4d.mqtt;

import java.util.Map;

import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;

import com.hoperun.c4d.bean.vo.IMessage;
import com.hoperun.c4d.util.SystemConfig;

/**
 * 
 * ClassName: IMqttClient
 * @description
 * @author yin_changbao
 * @Date   Jan 29, 2016
 *
 */
public interface IMqttClient {

	
	/**
	 * set Deprecated because  paho discarded the wWildcard, which is important feature
	 * @param topic
	 * @param message
	 */
	@Deprecated
	public void publish(String topic,IMqttMessage message);
	
	
	public MqttDeliveryToken publish(String topic,IMqttMessage message,int qos,boolean retained)throws MqttPersistenceException, MqttException;
	
	public void subscribe(String...topic);
	public void subscribe(Map<String,Integer> topicAndOos);
	public void unsubscribe(String...topic);
	public void close(boolean forcibly,Long quiesceTimeout);
	
	
}
