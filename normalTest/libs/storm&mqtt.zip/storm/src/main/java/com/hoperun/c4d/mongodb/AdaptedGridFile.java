package com.hoperun.c4d.mongodb;

import java.io.File;

import com.hoperun.c4d.util.FileUtil;
import com.hoperun.ubi.cache.util.StringUtil;

public abstract class AdaptedGridFile implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2643710920332893212L;
	protected File file;
	public AdaptedGridFile(File file) {
		this.file = file;
	}
	public File getFile() {
		return file;
	}
	public void setFile(File file) {
		this.file = file;
	}
	
	public String getFileSuffix(){
		if(this.file==null||StringUtil.isEmpty(this.file.getName()))
			return null;
		String fileName = this.file.getName();
		if(fileName.lastIndexOf(".")>-1)
			return fileName.substring(fileName.lastIndexOf(".")+1);
		else 
			return fileName;
		
	}
	
	public String getFileName(){
		return this.file.getName();
	}
	
	public String getMd5(){
		return FileUtil.getMd5(this.file);
	}
}
