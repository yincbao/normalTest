package com.hoperun.c4d.common.constant;

public enum AlarmType {
	
	over_speed_alarm((byte)0x01,"over speed alarm"),
	low_voltage_alarm((byte)0x02,"low speed alarm"),
	temperature_alarm((byte)0x03,"temperature alarm"),
	hard_acceleration_alarm((byte)0x04,"hard acceleration alarm"),
	hard_deceleration_alarm((byte)0x05,"hard deceleration alarm"),
	parking_without_ignition_off_alarm((byte)0x06,"parking without ignition off alarm"),
	tow_alarm((byte)0x07,"tow alarm"),
	high_RPM_speed_alarm((byte)0x08,"high RPM speed alarm"),
	pow_on_alarm((byte)0x09,"pow on alarm"),
	exhaust_emission_alarm((byte)0x0A,"exhaust emission alarm"),
	quick_lane_change_alarm((byte)0x0B,"quick lane change alarm"),
	sharp_turn_alarm((byte)0x0C,"sharp turn alarm"),
	fatigue_driving_alarm((byte)0x0D,"fatigue driving alarm"),
	power_off_alarm((byte)0x0E,"power off alarm"),
	zone_alarm((byte)0x0F,"zone alarm"),
	emergency_alarm((byte)0x10,"emergency alarm"),
	collision_alarm((byte)0x11,"collision alarm"),
	tamper_alarm((byte)0x07,"tow alarm"),
	illegal_entry_alarm((byte)0x13,"illegal entry alarm"),
	illegal_ignition_alarm((byte)0x14,"illegal ignition alarm"),
	OBD_wire_cut_alarm((byte)0x15,"OBD wire cut alarm"),
	ignition_on((byte)0x16,"ignition on"),
	ignition_off((byte)0x17,"ignition off"),
	MIL_alarm((byte)0x18,"MIL alarm"),
	unlock_alarm((byte)0x19,"unlock alarm"),
	no_swipe_card_alarm((byte)0x1A,"no swipe card alarm"),
	;
	
	public Byte code;
	public String name;
	private AlarmType(Byte code, String name) {
		this.code = code;
		this.name = name;
	}

}
