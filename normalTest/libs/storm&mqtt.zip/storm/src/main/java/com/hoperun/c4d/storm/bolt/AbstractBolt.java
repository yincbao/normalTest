package com.hoperun.c4d.storm.bolt;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.base.BaseRichBolt;

/**
 * 
 * ClassName: AbstractBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public abstract class AbstractBolt extends BaseRichBolt{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6299216499661128892L;
	protected ApplicationContext applicationContext= null; 

	protected OutputCollector collector;
	
	@Override
	public void prepare(@SuppressWarnings("rawtypes") Map arg0, TopologyContext arg1, OutputCollector arg2) {
		this.collector = arg2;
		this.applicationContext = new ClassPathXmlApplicationContext(new String[]{"classpath*:/spring-all.xml"});
	}
}
