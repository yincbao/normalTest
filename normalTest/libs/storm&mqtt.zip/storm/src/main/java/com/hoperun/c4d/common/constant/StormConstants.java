package com.hoperun.c4d.common.constant;

public interface StormConstants {

	
	public final String CHINA = "China";
	public final String TAIWAN = "Taiwan";
	public final String XIANGGANG = "Hong Kong";
	public final String AOMEN = "Macao";
	
	public static final String MEXICO = "Mexico";

	public static String GOOGLE_LOCATION_QURTY_URL = "http://maps.google.cn/maps/api/geocode/json?latlng=%g,%g&language=EN";

	
	public final int TIMEOUT = 30*60 * 1000;
	public final int CONNECT_TIMEOUT = 15*60*1000;
	public final int SOCKET_TIMEOUT = 30*60*1000;
	public final String HTTP_HEAD_CONTENT_TYPE = "Content-Type";
	public final String HTTP_HEAD_CONTENT_TYPE_VALUE = "application/json; charset=utf-8";
	
	public final String SPLITOR = "-SPLITOR-";
	
	
	public final String CACHE_KEY_PREFIX_PSL_SESSION_SECTION_SEQUENCE = "CACHE_KEY_PREFIX_PSL_SESSION_SECTION_SEQUENCE";
	public final String CACHE_KEY_PREFIX_PSL_SESSION_SECTION = "CACHE_KEY_PREFIX_PSL_SESSION_SECTION";
	
	public final String CACHE_KEY_PREFIX_HL_COUNTERKEY = "CACHE_KEY_PREFIX_HL_COUNTERKEY";
	
	public final String CACHE_KEY_PREFIX_HL_LASTREPORTTIME = "CACHE_KEY_PREFIX_HL_LASTREPORTTIME";
	
	
	
	/**mqtt topic names***/
	public final String MQTT_TOPIC_FUNCTION_ALARM_ = "storm/alarm";
	public final String MQTT_TOPIC_FUNCTION_HL_ = "storm/hl";
	public final String MQTT_TOPIC_FUNCTION_PSL_ = "storm/psl";
	
}
