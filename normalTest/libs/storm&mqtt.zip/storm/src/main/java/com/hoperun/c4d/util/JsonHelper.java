package com.hoperun.c4d.util;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonMethod;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;
import org.codehaus.jackson.type.JavaType;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


/**
 * 
 * 
 * @ClassName: ConfigException.java
 * @Description:
 * @author YinChang-bao
 * @date Nov 16, 2015
 *
 */
public class JsonHelper {

	private static final Log logger = LogFactory.getLog(JsonHelper.class);

	public static String bean2Json(Object bean) {
		return bean2Json(bean, true);
	}

	public static String bean2Json(Object bean, boolean displayEmpty) {
		try {
			ObjectMapper mapper = new ObjectMapper().setVisibility(JsonMethod.FIELD, Visibility.ANY);

			if (displayEmpty)
				mapper.setSerializationInclusion(Inclusion.NON_EMPTY);
			mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, true);
			StringWriter sw = new StringWriter();
			JsonGenerator gen = new JsonFactory().createJsonGenerator(sw);
			mapper.writeValue(gen, bean);
			gen.close();
			return sw.toString();
		} catch (IOException e) {
			logger.error("bean2Json error" + e.getMessage(), e);
		}
		return null;

	}

	public static <T> T json2Bean(String jsonStr, Class<T> target, boolean parseEmpty) {

		try {
			ObjectMapper mapper = new ObjectMapper().setVisibility(JsonMethod.FIELD, Visibility.ANY);

			if (parseEmpty)
				mapper.setSerializationInclusion(Inclusion.NON_EMPTY);
			mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, true);

			T value = mapper.readValue(jsonStr, target);
			return value;
		} catch (Exception e) {
			logger.error("json2Bean error" + e.getMessage(), e);
		}
		return null;

	}

	public static <T> T json2Bean(String jsonStr, Class<?> collectionType,Class<T> generics, boolean parseEmpty) {

		if(generics==null)
			return (T) json2Bean(jsonStr,collectionType,parseEmpty);
		try {
			
			ObjectMapper mapper = new ObjectMapper().setVisibility(JsonMethod.FIELD, Visibility.ANY);
			JavaType javaType = mapper.getTypeFactory().constructParametricType(collectionType, generics); 
			if (parseEmpty)
				mapper.setSerializationInclusion(Inclusion.NON_EMPTY);
			mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(JsonGenerator.Feature.ESCAPE_NON_ASCII, true);
			T value = mapper.readValue(jsonStr, javaType);
			return value;
		} catch (Exception e) {
			logger.error("json2Bean error" + e.getMessage(), e);
		}
		return null;

	}
	public static <T> T json2Bean(String jsonStr, Class<T> target) {

		return json2Bean(jsonStr, target, true);

	}
	
	
	
	public static Gson getGson(Map<Class<?>, Object> adapters) {
		Gson gson = null;
		if (adapters != null) {
			GsonBuilder gsonBuilder = new GsonBuilder();
			for (Map.Entry<Class<?>, Object> entry : adapters.entrySet()) {
				gsonBuilder.registerTypeAdapter(entry.getKey(), entry.getValue());
			}
			gson = gsonBuilder.create();
		} else {
			gson = new Gson();
		}
		return gson;
	}
	
	public static <T> T gson2Bean(String json, Class<T> classOfT) {
		return gson2Bean(json, classOfT, null);
	}

	public static <T> T gson2Bean(String json, Class<T> classOfT, Map<Class<?>, Object> adapters) {
		Gson gson = getGson(adapters);
		return gson.fromJson(json, classOfT);
	}

	public static String bean2Gson(Object jsonElement) {
		return bean2Gson(jsonElement, null);
	}

	public static String bean2Gson(Object jsonElement, Map<Class<?>, Object> adapters) {
		Gson gson = getGson(adapters);
		return gson.toJson(jsonElement);
	}
}
