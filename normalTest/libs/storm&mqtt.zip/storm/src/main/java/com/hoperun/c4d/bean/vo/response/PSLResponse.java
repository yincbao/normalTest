package com.hoperun.c4d.bean.vo.response;

import java.util.List;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.common.constant.Topics;

public class PSLResponse implements IResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3374084746836072703L;
	
	List<OsmNodes> allNodes;
	List<OsmWays> allWays;
	
	String session;
	
	public PSLResponse(String session,List<OsmNodes> allNodes, List<OsmWays> allWays) {
		super();
		this.allNodes = allNodes;
		this.allWays = allWays;
		this.session = session;
	}

	

	public List<OsmNodes> getAllNodes() {
		return allNodes;
	}

	public void setAllNodes(List<OsmNodes> allNodes) {
		this.allNodes = allNodes;
	}

	public List<OsmWays> getAllWays() {
		return allWays;
	}

	public void setAllWays(List<OsmWays> allWays) {
		this.allWays = allWays;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}



	@Override
	public String getMessagePath() {
		return "psl";
	}



	@Override
	public String topicName() {
		return Topics.PSL_NODES_SECTION;
	}
	

}
