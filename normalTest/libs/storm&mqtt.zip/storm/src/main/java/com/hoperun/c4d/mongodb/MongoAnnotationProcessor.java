package com.hoperun.c4d.mongodb;

import java.util.HashMap;
import java.util.Map;

import com.hoperun.c4d.util.StringUtil;

/**
 * 
 * ClassName: MongoAnnotationProcessor
 * 
 * @description
 * @author yin_changbao
 * @Date Oct 16, 2015
 *
 */
public class MongoAnnotationProcessor {

	public static <T> String getDatabase(Class<T> clazz) {
		com.hoperun.c4d.mongodb.Mongo schema = annotation(clazz);
		if (schema != null && !StringUtil.isEmpty(schema.database()))
			return schema.database();
		return null;
	}

	public static <T> String getCollection(Class<T> clazz) {
		com.hoperun.c4d.mongodb.Mongo schema = annotation(clazz);
		if (schema != null && !StringUtil.isEmpty(schema.database()))
			return schema.collection();
		return null;
	}
	
	public static <T> String getBucket(Class<T> clazz) {
		com.hoperun.c4d.mongodb.Mongo schema = annotation(clazz);
		if (schema != null && !StringUtil.isEmpty(schema.database()))
			return schema.bucket();
		return null;
	}

	private static <T> com.hoperun.c4d.mongodb.Mongo annotation(Class<T> clazz) {
		if (clazz == null)
			return null;
		if (!clazz.isAnnotationPresent(com.hoperun.c4d.mongodb.Mongo.class))
			return null;
		Map<Class<?>, Object> adapterMap = new HashMap<Class<?>, Object>();
		com.hoperun.c4d.mongodb.Mongo schema = clazz.getAnnotation(com.hoperun.c4d.mongodb.Mongo.class);
		return schema;
	}
}
