package com.hoperun.c4d.bean.po;


public class GpsData implements java.io.Serializable,java.lang.Comparable<GpsData>{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -2877295362914042698L;

	private long gpsTime;
	
	private double latitude;
	
	private double longitude;
	
	private double speed;
	
	
	public GpsData() {
		super();
	}

	public GpsData(long gpsTime) {
		super();
		this.gpsTime = gpsTime;
	}

	public long getGpsTime() {
		return gpsTime;
	}

	public void setGpsTime(long gpsTime) {
		this.gpsTime = gpsTime;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}


	@Override
	public String toString() {
		return "GpsData [gpsTime=" + gpsTime + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", speed=" + speed
				+ "]";
	}

	public int compareTo(GpsData o) {
		if(o==null||o.gpsTime==0)
			return 1 ;
		if(this.gpsTime==0)
			return -1;
		return (int) (this.gpsTime-o.gpsTime);
	}
	
	
	public boolean equalIngnoreTime(GpsData o){
		if(this.latitude==o.latitude&&this.longitude==o.longitude&&this.speed==o.speed)
			return true;
		else 
			return false;
	}

	public GpsData(long gpsTime, double latitude, double longitude, double speed) {
		super();
		this.gpsTime = gpsTime;
		this.latitude = latitude;
		this.longitude = longitude;
		this.speed = speed;
	}
	
	

}
