package com.hoperun.c4d.common.constant;

public enum ETlvType {

	over_speed_alarm((byte)0x01,"over speed alarm",1),
	low_voltage_alarm((byte)0x02,"low speed alarm"),
	temperature_alarm((byte)0x03,"temperature alarm"),
	hard_acceleration_alarm((byte)0x04,"hard acceleration alarm",3),
	hard_deceleration_alarm((byte)0x05,"hard deceleration alarm",2),
	parking_without_ignition_off_alarm((byte)0x06,"parking without ignition off alarm"),
	tow_alarm((byte)0x07,"tow alarm"),
	high_RPM_speed_alarm((byte)0x08,"high RPM speed alarm",0),
	pow_on_alarm((byte)0x09,"pow on alarm"),
	exhaust_emission_alarm((byte)0x0A,"exhaust emission alarm"),
	quick_lane_change_alarm((byte)0x0B,"quick lane change alarm"),
	sharp_turn_alarm((byte)0x0C,"sharp turn alarm",4),
	fatigue_driving_alarm((byte)0x0D,"fatigue driving alarm"),
	power_off_alarm((byte)0x0E,"power off alarm"),
	zone_alarm((byte)0x0F,"zone alarm"),
	emergency_alarm((byte)0x10,"emergency alarm"),
	collision_alarm((byte)0x11,"collision alarm"),
	tamper_alarm((byte)0x07,"tow alarm"),
	illegal_entry_alarm((byte)0x13,"illegal entry alarm"),
	illegal_ignition_alarm((byte)0x14,"illegal ignition alarm"),
	OBD_wire_cut_alarm((byte)0x15,"OBD wire cut alarm"),
	ignition_on((byte)0x16,"ignition on"),
	ignition_off((byte)0x17,"ignition off"),
	MIL_alarm((byte)0x18,"MIL alarm"),
	unlock_alarm((byte)0x19,"unlock alarm"),
	no_swipe_card_alarm((byte)0x1A,"no swipe card alarm"),
	;
	
	public Byte code;
	public String name;
	public int ubiCode;
	
	private ETlvType(byte code, String name,int ubiCode){
		this.code = code;
		this.name = name;
		this.ubiCode = ubiCode;
	}
	
	private ETlvType(byte code, String name){
		this.code = code;
		this.name = name;
	}
	
	public static ETlvType fromCode(Byte code){
		if(code == null)
			throw new java.lang.IllegalArgumentException(
					"No enum found for the passed code: " + code);
		ETlvType[] types = ETlvType.values();
		for (int i = 0; i < types.length; i++) {
			if(types[i].code == code){
				return types[i];
			}
		}
		throw new java.lang.IllegalArgumentException(
				"No enum found for the passed code: " + code);
	}
	
	public static void main(String[] args){
		ETlvType type = ETlvType.fromCode((byte)0x10);
		System.out.println(type);
	}
}
