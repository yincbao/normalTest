package com.hoperun.c4d.bean.po;

import com.hoperun.c4d.common.constant.AlarmType;

public class Alarm implements java.io.Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -542726686578441838L;

	private AlarmType type;
	
	private String alarmDesc;
	
	private String threadhold;

	public AlarmType getType() {
		return type;
	}

	public void setType(AlarmType type) {
		this.type = type;
	}

	public String getAlarmDesc() {
		return alarmDesc;
	}

	public void setAlarmDesc(String alarmDesc) {
		this.alarmDesc = alarmDesc;
	}

	public String getThreadhold() {
		return threadhold;
	}

	public void setThreadhold(String threadhold) {
		this.threadhold = threadhold;
	}
	
	

}
