package com.hoperun.c4d.mqtt.pool;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;

import com.hoperun.c4d.mqtt.IMqttClient;
import com.hoperun.c4d.mqtt.MqttClient;
import com.hoperun.c4d.util.SystemConfig;

/**
 * 
 * ClassName: PooledMqttClientFactory
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class PooledMqttClientFactory extends BasePooledObjectFactory<IMqttClient>{
	
	private static final Log logger = LogFactory.getLog(PooledMqttClientFactory.class);
	final String host = SystemConfig.getProperty("storm.mqtt.server","tcp://10.20.71.161:61613");
	final String userName = SystemConfig.getProperty("storm.mqtt.userName","admin");
	final String password = SystemConfig.getProperty("storm.mqtt.passwd","password");
	final String clientId = SystemConfig.getProperty("storm.mqtt.clientId","Server1");
	
	final int connectionTimeout = SystemConfig.getIntProperty("storm.mqtt.connection.timeout.seconds",30);
	final int keepAliveInterval = SystemConfig.getIntProperty("storm.mqtt.connection.keepAliveInterval.seconds",10);
	final boolean cleanSession = SystemConfig.getBooleanProperty("storm.mqtt.session.clean", false);
	final boolean useMemoryPersistence = SystemConfig.getBooleanProperty("storm.mqtt.data.Persistence.useMemory", false);
	final String dataDir = SystemConfig.getProperty("storm.mqtt.data.Persistence.dir", System.getProperty("user.dir"));

	@Override
	public IMqttClient create() throws Exception {
		logger.debug("applying for create object MqttClient");
		return new MqttClient();
	}

	@Override
	public PooledObject<IMqttClient> wrap(IMqttClient obj) {
		return new DefaultPooledObject<IMqttClient>(obj);
	}


}
