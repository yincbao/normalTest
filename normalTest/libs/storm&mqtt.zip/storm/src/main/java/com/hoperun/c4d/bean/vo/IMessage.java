package com.hoperun.c4d.bean.vo;

public interface IMessage extends java.io.Serializable{
	
	public String getMessagePath();
	public void setSession(String session);
	public String topicName();
	
	public String getSession();

}
