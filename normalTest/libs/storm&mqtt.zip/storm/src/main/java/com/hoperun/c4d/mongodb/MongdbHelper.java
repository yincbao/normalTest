package com.hoperun.c4d.mongodb;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoperun.c4d.util.JsonHelper;
import com.hoperun.c4d.util.StringUtil;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;


/**
 * 
* @ClassName: MongdbHelper 
* @Description: 
* @author YinChang-bao
* @date Nov 9, 2015 4:11:44 PM 
*
 */
public class MongdbHelper {
	
	private static final Log logger = LogFactory.getLog(MongdbHelper.class);
	
	public static <T> Map<String, Object> bean2Map(T obj) {

		if (obj == null) {
			return null;
		}
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
			PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
			for (PropertyDescriptor property : propertyDescriptors) {
				String key = property.getName();

				if (!key.equals("class")) {
					Method getter = property.getReadMethod();
					Object value = getter.invoke(obj);

					map.put(key, value);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return map;

	}

	@SuppressWarnings("unchecked")
	public static <T> DBObject bean2DBObject(T bean) throws IllegalArgumentException, IllegalAccessException {
		if (bean == null) {
			return null;
		}
		DBObject dbObject = new BasicDBObject();
		Field[] fields = bean.getClass().getDeclaredFields();
		for (Field field : fields) {
			String varName = field.getName();
			boolean accessFlag = field.isAccessible();
			if (!accessFlag) {
				field.setAccessible(true);
			}
			Object param = field.get(bean);
			if (param == null) {
				continue;
			} else if (param instanceof Integer) {
				int value = ((Integer) param).intValue();
				dbObject.put(varName, value);
			} else if (param instanceof String) {
				String value = (String) param;
				dbObject.put(varName, value);
			} else if (param instanceof Double) {
				double value = ((Double) param).doubleValue();
				dbObject.put(varName, value);
			} else if (param instanceof Float) {
				float value = ((Float) param).floatValue();
				dbObject.put(varName, value);
			} else if (param instanceof Long) {
				long value = ((Long) param).longValue();
				dbObject.put(varName, value);
			} else if (param instanceof Boolean) {
				boolean value = ((Boolean) param).booleanValue();
				dbObject.put(varName, value);
			} else if (param instanceof Date) {
				Date value = (Date) param;
				dbObject.put(varName, value);
			} else if (param instanceof List) {
				List<Object> list = (List<Object>) param;
				dbObject.put(varName, list);
			} else if (param instanceof Map) {
				Map<Object, Object> map = (Map<Object, Object>) param;
				dbObject.put(varName, map);
			}
			field.setAccessible(accessFlag);
		}
		return dbObject;
	}
	
	
	public static BasicDBObject conditions( Map<String, Object> condition) {
		Iterator<String> ite= condition.keySet().iterator();
		BasicDBObject mql = null;
		StringBuffer bson = new StringBuffer("query BSON:{ ");
		while(ite.hasNext()){
			if(mql==null)
				mql = new BasicDBObject();
			String k = ite.next();
			Object v = condition.get(k);
			bson.append(""+"\""+k+"\":"+v+",");
			mql.append(k, v);
		}
		String log = bson.toString();
		log = log.substring(0,log.lastIndexOf(","));
		logger.debug(log+"}");
		return mql;
		
	}
	
	public static BasicDBObject projections( Map<String, Integer> projection) {
		if(projection==null)
			return null;
		Iterator<String> ite= projection.keySet().iterator();
		BasicDBObject mql = null;
		StringBuffer bson = new StringBuffer("query projection: {");
		while(ite.hasNext()){
			if(mql==null)
				mql = new BasicDBObject();
			String k = ite.next();
			Integer v = projection.get(k);
			bson.append(""+"\""+k+"\":"+v+",");
			mql.append(k, v);
		}
		String log = bson.toString();
		log = log.substring(0,log.lastIndexOf(","));
		logger.debug(log+"}");
		return mql;
		
	}
	
	public static <T> T encap(DBObject result,Class<T> clazz){
		return JsonHelper.json2Bean(JSON.serialize(result), clazz);
	}
	
	public static Object[] parseFilters(Object[][] filter,String key){
		if(StringUtil.isEmpty(key))
			return null;
		if(filter!=null&&filter.length>0){
			for(Object[] le:filter){
				if(le!=null&&le.length>0){
					if(key.equalsIgnoreCase((String) le[0]))
						return le;
				}
				
			}
		}
		return null;
	}
	public static List<Object[]> parseMultiFilters(Object[][] filter,String key){
		if(StringUtil.isEmpty(key))
			return null;
		List<Object[]> re = new ArrayList<Object[]>();
		if(filter!=null&&filter.length>0){
			for(Object[] le:filter){
				if(le!=null&&le.length>0){
					if(key.equalsIgnoreCase((String) le[0]))
						re.add(le);
				}
				
			}
		}
		return re;
	}
}
