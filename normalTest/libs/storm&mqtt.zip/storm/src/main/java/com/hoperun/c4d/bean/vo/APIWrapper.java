package com.hoperun.c4d.bean.vo;

import com.hoperun.ubi.cache.util.JsonHelper;

public class APIWrapper implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5694811494023160800L;

	private String message;
	
	private String session;
	
	private String topic;
	
	private String path;

	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	
	private APIWrapper(String message, String session, String topic, String path) {
		super();
		this.message = message;
		this.session = session;
		this.topic = topic;
		this.path = path;
	}
	

	public APIWrapper() {
		super();
	}

	public static APIWrapper build(IMessage request) {
		return new APIWrapper(JsonHelper.bean2Json(request),request.getSession(),request.topicName(),request.getMessagePath());
	}
	
	@Override
	public String toString(){
		return JsonHelper.bean2Json(this);
	}


}
