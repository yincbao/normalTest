package com.hoperun.c4d.service;

import java.util.List;

import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.bean.po.OsmWays;
/**
 * 
 * ClassName: IPostSpeedLimitService
 * @description
 * @author yin_changbao
 * @Date   Dec 8, 2015
 *
 */
public interface IOsmWaysService extends java.io.Serializable{

	/**
	 * fetch street speed limitation value via coordinate
	 * @param longitude
	 * @param latitude
	 * @return
	 */
	public List<OsmWays> fetchSpeedLimit(Double longitude,Double latitude,Double searchRange);

	List<OsmWays> fetchSpeedLimit(List<OsmNodes> nodes);
	public String[] assembleWaysName(Double longitude, Double latitude);
	public void assembleWaysMaxSpeed(List<OsmWays> osmWays,String[] area);
	
	public void assembleNodes(List<OsmNodes> osmNodes,List<OsmWays> osmWays);
}
