package com.hoperun.c4d.storm.bolt.hotLocation;

import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.etc.ReaptCounter;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.common.constant.StormConstants;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.CacheUtil;
import com.hoperun.c4d.util.SystemConfig;
/**
 * 
 * ClassName: HLProcess3CountBolt
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class HLProcess3CountBolt extends AbstractBolt {

	private static final Log logger = LogFactory.getLog(HLProcess3CountBolt.class);
	private static final long serialVersionUID = 886149197481637894L;
	private OutputCollector collector;
	private ReaptCounter<OsmWays> hlCounter;
	private static int interval = SystemConfig.getIntProperty("hl.window.interval.seconds",3);

	public void cleanup() {
		hlCounter = null;
	}

	public void execute(Tuple paramTuple) {

		try {
			String lastReportTime = CacheUtil.buildKey(StormConstants.CACHE_KEY_PREFIX_HL_LASTREPORTTIME, "");
			Long last = CacheUtil.tryCache(lastReportTime, Long.class);
			OsmWays way = (OsmWays) paramTuple.getValue(0);
			int count = paramTuple.getInteger(1);
			if(hlCounter.getAttr()==null)
				hlCounter.setAttr(way);
			AtomicInteger ai = this.hlCounter.getCounter();
			if (ai == null) {
				ai = new AtomicInteger();
				this.hlCounter.setCounter(ai);
			}
			ai.addAndGet(count);
			long currentTime = System.currentTimeMillis();
			if (last == null || currentTime >= last + interval*1000) {
				collector.emit(new Values(way,hlCounter,last));
				CacheUtil.updateCache(lastReportTime, currentTime);
			}
			collector.ack(paramTuple);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			collector.fail(paramTuple);
		}

	}

	public void prepare(Map paramMap, TopologyContext paramTopologyContext, OutputCollector paramOutputCollector) {
		super.prepare(paramMap, paramTopologyContext, paramOutputCollector);
		this.collector = paramOutputCollector;
		this.hlCounter = new ReaptCounter<OsmWays>();
	}

	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("wayIn3", "hlCounter","lastWindowTime"));
	}

	public Map<String, Object> getComponentConfiguration() {
		return null;
	}

}
