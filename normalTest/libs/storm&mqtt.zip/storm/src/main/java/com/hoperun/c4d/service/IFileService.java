package com.hoperun.c4d.service;

import java.io.File;
import java.util.List;

public interface IFileService {

	void saveImg(String filePath);

	void delImg(String fileName);

	List<File> queryImg(String fileName,String output);

}
