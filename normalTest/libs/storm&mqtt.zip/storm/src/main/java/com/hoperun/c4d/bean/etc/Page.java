package com.hoperun.c4d.bean.etc;

import java.util.List;

public class Page<E> implements java.io.Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2494193536755939731L;
	private int pageSize;
	private int pageNo;
	private int total;
	private Object lastIdx;//mongodb paging used
	List<E> data;
	
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	
	
	public Object getLastIdx() {
		return lastIdx;
	}
	public void setLastIdx(Object lastIdx) {
		this.lastIdx = lastIdx;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public List<E> getData() {
		return data;
	}
	public void setData(List<E> data) {
		this.data = data;
	}
	public Page(int pageSize, int pageNo) {
		super();
		this.pageSize = pageSize;
		this.pageNo = pageNo;
	}
	public Page(int pageSize, int pageNo, int total, List<E> data) {
		super();
		this.pageSize = pageSize;
		this.pageNo = pageNo;
		this.total = total;
		this.data = data;
	}
	@Override
	public String toString() {
		return "Page [pageSize=" + pageSize + ", pageNo=" + pageNo + ", total=" + total + ", lastIdx=" + lastIdx
				+ ", data=" + data + "]";
	}
	
	
	
}
