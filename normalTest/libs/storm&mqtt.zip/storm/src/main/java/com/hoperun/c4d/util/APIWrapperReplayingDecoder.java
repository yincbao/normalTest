package com.hoperun.c4d.util;

import java.nio.charset.Charset;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.handler.codec.replay.ReplayingDecoder;

import com.hoperun.c4d.bean.vo.APIWrapper;
import com.hoperun.ubi.cache.util.JsonHelper;

/**
 * 
 * ClassName: OBD2SmartReplayingDecoder
 * @description
 * @author yin_changbao
 * @Date   Oct 27, 2015
 *
 */
public class APIWrapperReplayingDecoder extends ReplayingDecoder<APIWrapperDecoderState> {

	private static final Log logger = LogFactory.getLog(APIWrapperReplayingDecoder.class);
	private final static String KEY_RESPONSE_START = "{\"message\":";
	private final static byte KEY_END_0 = 0x0d;
	private final static byte KEY_END_1 = 0x0a;
	
	private StringBuilder sb = new StringBuilder();


	public APIWrapperReplayingDecoder() {
		// Set the initial state.
		super(APIWrapperDecoderState.ReadA);
	}

	
	private boolean valid(String body){
		try{
			JsonHelper.json2Bean(body, APIWrapper.class);
			return true;
		}catch(Exception e){
			return false;
		}
		
		
	}
	@Override
	protected Object decode(ChannelHandlerContext ctx, Channel channel, ChannelBuffer buffer, APIWrapperDecoderState state)
			throws Exception {

		byte[] ABCDEFG = null;
		try {
			String body = buffer.toString(Charset.defaultCharset());
			switch (state) {
			case ReadA:
				logger.debug(String.format("The package data in bytely >>> (%s) ", body));
				if (body.indexOf(KEY_RESPONSE_START)<0) {
					logger.error(String.format("The package is invaild start 0 (%s)", body));
					sb.append(body);
					checkpoint(APIWrapperDecoderState.ReadA);
				}else
					checkpoint(APIWrapperDecoderState.ReadBCDEFG);
			case ReadBCDEFG:
				String[] sbody = body.split(KEY_RESPONSE_START);
				if(sbody==null||sbody.length==0){
					sb.append(body);
					checkpoint(APIWrapperDecoderState.ReadA);
				}else{
					int l = sbody.length;
					for(int i = 0;i<l-1;i++){
						sb.append(sbody[i]);
						if(i==0)
							return sb.toString();
					}
				}
					
			default:
				checkpoint(APIWrapperDecoderState.ReadA);
				throw new Error("Shouldn't reach here.");
			}

		} catch (Exception e) {
			String message = "Cannot get package data.";
			if (ABCDEFG != null) {
				message = Arrays.toString(ABCDEFG);
			}
			logger.error("packageData=" + message, e);
			checkpoint(APIWrapperDecoderState.ReadA);
			return null;
		}
	}



}
