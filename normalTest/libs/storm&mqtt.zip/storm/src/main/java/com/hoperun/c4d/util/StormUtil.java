package com.hoperun.c4d.util;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.MessageEvent;

public final class StormUtil {
	
	private static final Log logger = LogFactory.getLog(StormUtil.class);
	
	
	private StormUtil(){}
	
	public static <E> boolean isEmptyCollection(Collection<E> collection){
		return collection==null||collection.isEmpty();
	}

	public static boolean isPortValid(int port) {
		if (port <= 0 || port >= 65535) {
			logger.fatal("No httpPort defined in agent.properties or httpPort invalid");
			return false;
		}
		if (checkPortOccupied("127.0.0.1", port)) {
			logger.fatal("port " + port + " has been occupied");
			return false;
		}
		return true;
	}

	public static boolean checkPortOccupied(String string, int port) {
		Socket cSocket = null;
		try {
			cSocket = new Socket(string, port);
		} catch (Exception e) {
			return false;
		} finally {
			try {
				if (cSocket != null && !cSocket.isClosed())
					cSocket.close();
			} catch (IOException e) {
			}
		}
		return true;
	}

	public static String getPid() {
		// get name representing the running Java virtual machine.
		String name = ManagementFactory.getRuntimeMXBean().getName();
		System.out.println(name);
		// get pid
		return name.split("@")[0];

	}

	public static <K, V> boolean isEmptyMap(Map<K, V> map) {
		if (map == null || map.isEmpty())
			return true;
		return false;

	}

	public static boolean isArrayEqual(Object[] array1, Object[] array2) {
		if (isEmptyArray(array1) || isEmptyArray(array2))
			return false;
		else if (array1.length != array2.length) {
			return false;
		} else {

			for (int i = 0; i < array1.length; i++) {
				if (array1[i] == array2[i] || array2[1].equals(array1[i]))
					return true;
				else
					continue;
			}
		}
		return false;
	}

	public static boolean isEmptyArray(Object[] array) {
		if (array == null || array.length <= 0)
			return true;
		return false;
	}

	public static ChannelBuffer wrapResponse(String msg) {
		ChannelBuffer buffer = ChannelBuffers.buffer(msg.length());
		buffer.writeBytes(msg.getBytes());
		return buffer;
	}

	public static String parseRequest(MessageEvent e) {
		ChannelBuffer acceptBuff = (ChannelBuffer) e.getMessage();
		return acceptBuff.toString(Charset.defaultCharset());
	}

	public static byte[] arrayAppend(byte[] prefix, byte[] sfix) {
		byte[] tmp = null;
		byte[] result = null;
		if ((prefix != null && prefix.length > 0)) {
			tmp = new byte[prefix.length];
			System.arraycopy(prefix, 0, tmp, 0, prefix.length);
		}
		if ((sfix != null && sfix.length > 0)) {
			if (tmp == null) {
				tmp = new byte[sfix.length];
				System.arraycopy(sfix, 0, tmp, 0, sfix.length);
				result = tmp;
			} else {
				result = new byte[tmp.length + sfix.length];
				System.arraycopy(tmp, 0, result, 0, tmp.length);
				System.arraycopy(sfix, 0, result, tmp.length, sfix.length);
			}

		} else
			result = tmp;

		return result;
	}

	public static <K, V> Map<K, V> hashMapPut(K k, V v) {
		Map<K, V> map = new HashMap<K, V>();
		map.put(k, v);
		return map;
	}
	
	public static <T> List<T> arrayListAdd(T t) {
		List<T> list = new ArrayList<T>();
		list.add(t);
		return list;
	}

	public static String getMacAddr() {
		byte[] mac;
		try {
			EPlatform platform = osCoreVersion();
			if (platform.equals(EPlatform.Linux))
				mac = NetworkInterface.getByName("eth0").getHardwareAddress();
			else
				mac = NetworkInterface.getByInetAddress(InetAddress.getLocalHost()).getHardwareAddress();
			StringBuffer macAddr = new StringBuffer();
			if (mac == null || mac.length < 1)
				return null;
			for (int i = 0; i < mac.length; i++)
				macAddr.append(new Formatter().format(Locale.getDefault(), "%02X%s", mac[i],
						(i < mac.length - 1) ? "-" : "").toString());
			return macAddr.toString();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	public static String getLocalIp() {
		String ip = "";
		EPlatform platform = osCoreVersion();
		try {
			if (platform.equals(EPlatform.Windows))
				ip = InetAddress.getLocalHost().getHostAddress();
			else if((platform.equals(EPlatform.Linux))){
				Enumeration<?> e1 = (Enumeration<?>) NetworkInterface.getNetworkInterfaces();
				while (e1.hasMoreElements()) {
					NetworkInterface ni = (NetworkInterface) e1.nextElement();
					if (!ni.getName().equals("eth0")) {
						continue;
					} else {
						Enumeration<?> e2 = ni.getInetAddresses();
						while (e2.hasMoreElements()) {
							InetAddress ia = (InetAddress) e2.nextElement();
							if (ia instanceof Inet6Address)
								continue;
							ip = ia.getHostAddress();
						}
						break;
					}
				}
			}
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return ip;
	}

	
	public static String globalThread(){
		return (getMacAddr()+"_"+getPid() + "_" + Thread.currentThread().getId()).trim().replaceAll("\\s*", "_");
	}
	
	public static String globalPid(){
		return (getMacAddr()+"_"+getPid()).trim().replaceAll("\\s*", "_");
	}
	

	public static String globalUUID(){
		String seed = UUID.randomUUID().toString();//uuid can't guarantee mac info.
		//return  "TCPSERVER"+new MD5().getMD5ofStr(seed+globalThread());
		return seed+globalThread();
	}
	
	public static <E> String printList(List<E> list){
		StringBuffer sb = new StringBuffer("[");
		if(isEmptyCollection(list))
			return "[]";
		for(E e:list)
			sb.append(e.toString()).append(",");
		sb.append("]");
		return sb.toString();
	}
	
	public static <E extends java.lang.Comparable<? super E>> int listContains(List<E> list,E  e){
		int chaju = Integer.MAX_VALUE;
		int targetIndex = -1;
		if(isEmptyCollection(list))
			return targetIndex;
		
		for(int i=0;i<list.size();i++){
			int co = Math.abs(list.get(i).compareTo(e));
			if(co==0)
				return i;
			else if(co<chaju)
				targetIndex = i;
		}
		return targetIndex;
	}
	
	public enum EPlatform {
		Any("any"),
		Linux("Linux"),
		Mac_OS("Mac OS"),
		Mac_OS_X("Mac OS X"),
		Windows("Windows"),
		OS2("OS/2"),
		Solaris("Solaris"),
		SunOS("SunOS"),
		MPEiX("MPE/iX"),
		HP_UX("HP-UX"),
		AIX("AIX"),
		OS390("OS/390"),
		FreeBSD("FreeBSD"),
		Irix("Irix"),
		Digital_Unix("Digital Unix"),
		NetWare_411("NetWare"),
		OSF1("OSF1"),
		OpenVMS("OpenVMS"),
		Others("Others");

		private EPlatform(String desc) {
			this.description = desc;
		}

		public String toString() {
			return description;
		}

		private String description;
	}

	public static EPlatform osCoreVersion() {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.indexOf("linux") >= 0)
			return EPlatform.Linux;
		else if (os.indexOf("windows") >= 0)
			return EPlatform.Windows;
		else if (os.indexOf("mac") >= 0 && os.indexOf("os") > 0 && os.indexOf("x") < 0)
			return EPlatform.Mac_OS;
		else if (os.indexOf("mac") >= 0 && os.indexOf("os") > 0 && os.indexOf("x") > 0)
			return EPlatform.Mac_OS_X;
		else if (os.indexOf("solaris") >= 0)
			return EPlatform.Solaris;
		else if (os.indexOf("digital") >= 0 && os.indexOf("unix") > 0)
			return EPlatform.Digital_Unix;
		else if (os.indexOf("aix") >= 0)
			return EPlatform.AIX;
		else
			return EPlatform.Any;
	}
}
