package com.hoperun.c4d.storm.bolt.alarm;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.po.AlarmData;
import com.hoperun.c4d.bean.vo.request.AlarmRequest;
import com.hoperun.c4d.storm.bolt.AbstractBolt;
import com.hoperun.c4d.util.CastelObdUtil;

public class AlarmParserBolt extends AbstractBolt{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5539328824824977837L;

	private static final Log logger = LogFactory.getLog(AlarmParserBolt.class);
	
	@Override
	public void execute(Tuple tuple) {
		
		AlarmRequest message = (AlarmRequest) tuple.getValue(0);
		logger.debug("alarm parser bolt got request"+message);
		List<AlarmData> alarm = CastelObdUtil.parseAlarmData(message.getAlarm(),message.getTime());
		collector.emit(new Values(message.getSession(),message.getGps(),alarm));
		collector.ack(tuple);
	}


	@Override
	public void declareOutputFields(OutputFieldsDeclarer paramOutputFieldsDeclarer) {
		paramOutputFieldsDeclarer.declare(new Fields("session","rawGpsData","alarm"));
		
	}

}
