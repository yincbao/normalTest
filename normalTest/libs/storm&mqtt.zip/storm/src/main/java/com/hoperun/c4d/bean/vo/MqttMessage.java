package com.hoperun.c4d.bean.vo;

import com.hoperun.c4d.mqtt.IMqttMessage;
import com.hoperun.ubi.cache.util.StringUtil;

/**
 * 
 * ClassName: MqttAlarmMessage
 * @description
 * @author yin_changbao
 * @Date   Feb 1, 2016
 *
 */
public class MqttMessage implements IMqttMessage{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1988027813863069300L;

	private String session;
	
	private String payload;
	
	
	

	public MqttMessage(String session, String payload) {
		super();
		this.session = session;
		this.payload = payload;
	}
	@Override
	public byte[] getBytes() {
		
		return this.toString().getBytes();
	}
	@Override
	public String toString(){
		session = StringUtil.nullToEmpty(session);
		payload = StringUtil.nullToEmpty(payload);
		return session+payload;
	}

	public String getSession() {
		return session;
	}


	public void setSession(String session) {
		this.session = session;
	}


	public String getPayload() {
		return payload;
	}


	public void setPayload(String payload) {
		this.payload = payload;
	}


}
