package com.hoperun.c4d.bean.vo.request;

import java.util.List;

import com.hoperun.c4d.bean.po.Coordinate;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.common.constant.Topics;
import com.hoperun.c4d.util.StormUtil;
import com.hoperun.exception.ExceptionCodeEnum;
import com.hoperun.exception.InterfaceException;
import com.hoperun.ubi.cache.util.StringUtil;

public class PSLRequest implements IRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4238156795315385246L;

	private String session;
	
	private List<OsmNodes> nodeList;
	
	private Coordinate coordinate;

	public PSLRequest(Coordinate coordinate) {
		this.coordinate = coordinate;
	}

	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public List<OsmNodes> getNodeList() {
		return nodeList;
	}

	public void setNodeList(List<OsmNodes> nodeList) {
		this.nodeList = nodeList;
	}

	public Coordinate getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Coordinate coordinate) {
		this.coordinate = coordinate;
	}

	@Override
	public void validate() throws InterfaceException {
		if(StringUtil.isEmpty(session))
			throw new InterfaceException(ExceptionCodeEnum.INTERFACE_EXCEPTION_NO_SESSION_SPECIFIED);
		if(coordinate==null)
			throw new InterfaceException(ExceptionCodeEnum.INTERFACE_EXCEPTION_INVALID_COORDINATE);
	}

	@Override
	public String getMessagePath() {
		return "";
	}

	@Override
	public String topicName() {
		return Topics.PSL_NODES_SECTION;
	}

	@Override
	public String toString() {
		return "PSLRequest [session=" + session + ", nodeList=" + StormUtil.printList(nodeList) + ", coordinate=" + coordinate + "]";
	}
	
	
}
