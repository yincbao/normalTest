package com.hoperun.c4d.dao.impl;

import java.io.File;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.hoperun.c4d.bean.po.ImgFile;
import com.hoperun.c4d.dao.IMFileDao;
import com.hoperun.c4d.mongodb.AdaptedGridFile;
import com.hoperun.c4d.mongodb.DaoSupport;
@Repository
public class MFileDaoImpl extends DaoSupport<ImgFile> implements IMFileDao {

	@Override
	public void save(AdaptedGridFile file) {
		super.saveFile(file);
		
	}
	
	@Override
	public <E extends AdaptedGridFile> boolean delete(Class<E> fileType,String fileName){
		return super.deleteFile(fileType, fileName);
	}


	@Override
	public  <E extends AdaptedGridFile> List<File> find(Class<E> fileType,String fileName, boolean fuzzy,String outputFolder){
		return super.findFile(fileType, fileName,fuzzy,outputFolder);
	}
}
