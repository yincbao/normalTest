package com.hoperun.c4d.bean.po;

public class PID implements java.io.Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6382097942381055183L;
	private double engineCoolantTemperature;//2105
	private int engineRPM;//210c
	private double fuelLevel;//212f
	private double fuelPressure;//2159
	private double intakeAirTemperature;//210f
	private double throttlePosition;//2111
	private double vehicleMaf;//2110
	private double vehicleSpeed;//210d
	private double batteryVoltage;//2142
	public double getEngineCoolantTemperature() {
		return engineCoolantTemperature;
	}
	public void setEngineCoolantTemperature(double engineCoolantTemperature) {
		this.engineCoolantTemperature = engineCoolantTemperature;
	}
	public int getEngineRPM() {
		return engineRPM;
	}
	public void setEngineRPM(int engineRPM) {
		this.engineRPM = engineRPM;
	}
	public double getFuelLevel() {
		return fuelLevel;
	}
	public void setFuelLevel(double fuelLevel) {
		this.fuelLevel = fuelLevel;
	}
	public double getFuelPressure() {
		return fuelPressure;
	}
	public void setFuelPressure(double fuelPressure) {
		this.fuelPressure = fuelPressure;
	}
	public double getIntakeAirTemperature() {
		return intakeAirTemperature;
	}
	public void setIntakeAirTemperature(double intakeAirTemperature) {
		this.intakeAirTemperature = intakeAirTemperature;
	}
	public double getThrottlePosition() {
		return throttlePosition;
	}
	public void setThrottlePosition(double throttlePosition) {
		this.throttlePosition = throttlePosition;
	}
	public double getVehicleMaf() {
		return vehicleMaf;
	}
	public void setVehicleMaf(double vehicleMaf) {
		this.vehicleMaf = vehicleMaf;
	}
	public double getVehicleSpeed() {
		return vehicleSpeed;
	}
	public void setVehicleSpeed(double vehicleSpeed) {
		this.vehicleSpeed = vehicleSpeed;
	}
	public double getBatteryVoltage() {
		return batteryVoltage;
	}
	public void setBatteryVoltage(double batteryVoltage) {
		this.batteryVoltage = batteryVoltage;
	}
	
	
}
