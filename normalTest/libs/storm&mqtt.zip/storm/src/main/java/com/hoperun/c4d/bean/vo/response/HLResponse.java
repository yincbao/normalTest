package com.hoperun.c4d.bean.vo.response;

import java.util.List;

import com.hoperun.c4d.bean.etc.ReaptCounter;
import com.hoperun.c4d.bean.po.OsmWays;
import com.hoperun.c4d.common.constant.Topics;

public class HLResponse implements IResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1067327648100431588L;
	
	private String session;
	
	
	public String getSession() {
		return session;
	}

	public void setSession(String session) {
		this.session = session;
	}

	private List<ReaptCounter<OsmWays>> content;

	public List<ReaptCounter<OsmWays>> getContent() {
		return content;
	}

	public void setContent(List<ReaptCounter<OsmWays>> content) {
		this.content = content;
	}

	public HLResponse(List<ReaptCounter<OsmWays>> content) {
		super();
		this.content = content;
	}

	public HLResponse() {
		super();
	}

	@Override
	public String getMessagePath() {
		return "hl";
	}

	@Override
	public String topicName() {
		return Topics.HL_NODES_SECTION;
	}
	
	
}
