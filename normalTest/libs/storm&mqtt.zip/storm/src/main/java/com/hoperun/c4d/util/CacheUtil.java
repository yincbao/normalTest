package com.hoperun.c4d.util;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoperun.ubi.cache.CacheManager;

/**
 * 
 * ClassName: CacheUtil
 * 
 * @description
 * @author yin_changbao
 * @Date Jan 11, 2016
 *
 */
public final class CacheUtil {

	private static final Log logger = LogFactory.getLog(CacheUtil.class);

	public static boolean isCacheOn() {
		String switchValue = SystemConfig.getProperty("ocs.cache.switch").trim();
		logger.debug(String.format("system cache switch:[%s]", switchValue));
		if (StringUtil.equals("on", switchValue) || StringUtil.equals("true", switchValue)
				|| StringUtil.equals("yes", switchValue))
			return true;
		else
			return false;
	}

	public static <T> T tryCache(String key, Class<T> clazz) {

		T t = CacheManager.getRedis3ClusterCache().get(key, clazz, null);
		if (t != null)
			logger.debug(String.format("cache key:[ %s ], hits ", key));

		return t;

	}

	/**
	 * 
	 * @Description: save or update k-v to cache, a all key and value should be
	 *               able to be Serialized, since mostly we use a distributed
	 *               cache. and even can be persistence
	 * @param k
	 *            key
	 * @param v
	 *            value
	 */
	public static <K  , V > void updateCache(K k, V v) {
		if (v != null)
			CacheManager.getRedis3ClusterCache().set(k, v);
	}

	/**
	 * 
	 * @Description: save or update k-v to cache
	 *
	 */
	public static void updateCache(String key, Map<? extends java.io.Serializable, ? extends java.io.Serializable> value) {
		if (value != null)
			CacheManager.getRedis3ClusterCache().set(key, value);
	}
	
	public static void updateCache(String key, Set<? extends java.io.Serializable> value) {
		if (value != null)
			CacheManager.getRedis3ClusterCache().set(key, value);
	}

	public static void updateCache(String key, Collection<? extends java.io.Serializable> value) {
		if (value != null)
			CacheManager.getRedis3ClusterCache().set(key, value);
	}

	public static String buildKey(String prefix, String... content) {

		StringBuilder sb = new StringBuilder(prefix);
		if (content != null && content.length > 0) {
			for (String con : content)
				sb.append("_").append(con);
			return sb.toString();
		}
		return prefix + "_";
	}
	
	public static void removeCache(String... key){
		if(key!=null&&key.length>0){
			for(String k:key)
				CacheManager.getRedis3ClusterCache().delete(k);
		}
		
	}
}
