package com.hoperun.c4d.mongodb;

import java.net.UnknownHostException;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.hoperun.c4d.util.StringUtil;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;


/**
 * 
* @ClassName: MongoDataSource 
* @Description: 
* @author YinChang-bao
* @date Nov 12, 2015 3:30:03 PM 
*
 */
public final class MongoDataSource {

	
	private static final Log logger = LogFactory.getLog(MongoDataSource.class);
	
	private int connectionsPerHost = 50;
	private int blockAmount = 50;
	private int maxWaitTime = 1000 * 60 * 2;
	private boolean autoReconnect = false;
	private int connectTimeout = 1000 * 60 * 1;
	
	private String host;
	private int port;
	private String userName;
	private String database;
	private String passwd;
	
	
	
	com.mongodb.MongoClient mongoClient = null;
	
	public void init(){
		logger.debug("starting mongodb datasource:"+host+"|"+port);
		 MongoCredential credential = null;
		if(needCredential()){
			logger.debug("starting mongodb with credential: "+ userName+"/******|"+database );
			credential = MongoCredential.createMongoCRCredential(userName, database, passwd.toCharArray());
		}
		MongoClientOptions.Builder build = new MongoClientOptions.Builder();
		build.connectionsPerHost(this.connectionsPerHost);
		//build.autoConnectRetry(false);
		build.threadsAllowedToBlockForConnectionMultiplier(this.blockAmount);
		build.maxWaitTime(this.maxWaitTime);
		build.connectTimeout(this.connectTimeout);
		MongoClientOptions options = build.build();
		//myOptions.isAutoConnectRetry();
		try {
			if(needCredential())
				mongoClient = new com.mongodb.MongoClient(new ServerAddress(host, port),Arrays.asList(credential), options);
			else
				mongoClient = new com.mongodb.MongoClient(new ServerAddress(host, port), options);
			logger.info("mongo datasource: "+host+"|"+port+" init done!");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}
	
	
	public void shutdown(){
		if(mongoClient!=null)
			mongoClient.close();
		logger.info("mongo datasource shutdown.");
	}
	private boolean needCredential(){
		return !StringUtil.isEmpty(userName)&&!StringUtil.isEmpty(passwd)&&!StringUtil.isEmpty(database);
	}

	public int getConnectionsPerHost() {
		return connectionsPerHost;
	}

	public void setConnectionsPerHost(int connectionsPerHost) {
		this.connectionsPerHost = connectionsPerHost;
	}

	public int getBlockAmount() {
		return blockAmount;
	}


	public void setBlockAmount(int blockAmount) {
		this.blockAmount = blockAmount;
	}


	public int getMaxWaitTime() {
		return maxWaitTime;
	}


	public void setMaxWaitTime(int maxWaitTime) {
		this.maxWaitTime = maxWaitTime;
	}


	public boolean isAutoReconnect() {
		return autoReconnect;
	}


	public void setAutoReconnect(boolean autoReconnect) {
		this.autoReconnect = autoReconnect;
	}


	public int getConnectTimeout() {
		return connectTimeout;
	}


	public void setConnectTimeout(int connectTimeout) {
		this.connectTimeout = connectTimeout;
	}


	public String getHost() {
		return host;
	}


	public void setHost(String host) {
		this.host = host;
	}


	public int getPort() {
		return port;
	}


	public void setPort(int port) {
		this.port = port;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getDatabase() {
		return database;
	}


	public void setDatabase(String database) {
		this.database = database;
	}


	public String getPasswd() {
		return passwd;
	}


	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}


	public com.mongodb.MongoClient getMongoClient() {
		return mongoClient;
	}


	public void setMongoClient(com.mongodb.MongoClient mongoClient) {
		this.mongoClient = mongoClient;
	}
	
	
}
