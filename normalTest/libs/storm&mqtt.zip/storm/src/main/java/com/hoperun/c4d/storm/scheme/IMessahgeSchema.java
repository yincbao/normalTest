package com.hoperun.c4d.storm.scheme;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import backtype.storm.spout.Scheme;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

import com.hoperun.c4d.bean.vo.IMessage;

public class IMessahgeSchema implements Scheme {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8229186144171413611L;
	
	public static final String IMESSAGE_SCHEME_KEY = "IMessage";
	
	private static final Log logger = LogFactory.getLog(IMessahgeSchema.class);

	@Override
	public List<Object> deserialize(byte[] arg0) {
		return new Values(new Object[] { deserializeIMessage(arg0) });
	}

	private IMessage deserializeIMessage(byte[] arg0) {
		ByteArrayInputStream bas = new ByteArrayInputStream(arg0);
		try {
			return(IMessage) new ObjectInputStream(bas).readObject();
		} catch (ClassNotFoundException e) {
			logger.error(e.getMessage(),e);
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
		}
		return null;
	}

	@Override
	public Fields getOutputFields() {
		return new Fields(new String[] { "IMessage" });
	}

}
