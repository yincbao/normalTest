package com.hoperun.c4d.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hoperun.c4d.bean.etc.Page;
import com.hoperun.c4d.bean.po.OsmNodes;
import com.hoperun.c4d.dao.IMOsmNodesDao;
import com.hoperun.c4d.service.IOsmNodesService;

/**
 * 
 * ClassName: OsmNodesServiceImpl
 * @description
 * @author yin_changbao
 * @Date   Dec 9, 2015
 *
 */
@Service("osmNodesService")
public class OsmNodesServiceImpl implements IOsmNodesService{

	
	private static final Log logger = LogFactory.getLog(OsmNodesServiceImpl.class);
	@Autowired
	protected IMOsmNodesDao mOsmNodesDao;
	
	public OsmNodes findNearestNode(Double longitude, Double latitude, Double maxDistance) {
		logger.debug("findNearestNode centerpoint("+longitude+","+latitude+") radius:"+maxDistance);
		return mOsmNodesDao.findNearestNode(longitude, latitude, maxDistance);
	}
	
	public List<OsmNodes> findNearestNodes(Double longitude, Double latitude, Double maxDistance) {
		logger.debug("findNearestNode centerpoint("+longitude+","+latitude+") radius:"+maxDistance);
		return mOsmNodesDao.findNearestNodes(longitude, latitude, maxDistance);
	}
	
	public Page<OsmNodes> pagingNearestNodes(Page<OsmNodes> page ,Double longitude, Double latitude, Double maxDistance) {
		logger.debug("findNearestNode centerpoint("+longitude+","+latitude+") radius:"+maxDistance);
		return mOsmNodesDao.pagingNearestNodes(page,longitude, latitude, maxDistance);
	}
}
