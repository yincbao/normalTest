package com.hoperun.c4d.dao;

import java.util.List;

import com.hoperun.c4d.bean.po.OsmHighWayMaxSpeed;


public interface IOsmDefaultHighwayMaxSpeedDao extends java.io.Serializable{

	List<OsmHighWayMaxSpeed> queryDefaultMaxSpeedByCondition(OsmHighWayMaxSpeed condition);
}
