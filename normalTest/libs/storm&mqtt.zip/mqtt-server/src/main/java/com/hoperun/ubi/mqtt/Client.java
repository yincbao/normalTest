package com.hoperun.ubi.mqtt;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class Client {
    private final static String userName = "admin";
    private final static String passWord = "password";
    private final static String HOST = "tcp://10.20.71.161:61613";
    private final static String TOPIC = "test/topic4/lisi";
    private static MqttClient client;
    public void close() throws Exception{
    	this.client.disconnect();
    	this.client.close();
    }

    public void doTest() throws Exception {
        client = new MqttClient(HOST, "java_client", new MemoryPersistence());
        MqttConnectOptions options = new MqttConnectOptions();
        options.setCleanSession(true);
        options.setUserName(userName);
        options.setPassword(passWord.toCharArray());
        
        client.setCallback(new MqttCallback() {

            public void messageArrived(String arg0, MqttMessage arg1)
                    throws Exception {
                System.out.println("Client messageArrived"+arg1.toString());
            }

            public void deliveryComplete(IMqttDeliveryToken arg0) {
                System.out.println("Client deliveryComplete");
            }

            public void connectionLost(Throwable arg0) {
                System.out.println("Client connectionLost");
                if (!client.isConnected()) {
                    try {
                        client.connect();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        client.connect(options);
        client.subscribe(TOPIC);
    }
    
    public static void main(String args[]){
    	try {
    		Client client = new Client();
    		client.doTest();
		} catch (Exception e) {
			
		} finally{
			try {
				client.close();
			} catch (MqttException e) {
			}
		}
    }
}