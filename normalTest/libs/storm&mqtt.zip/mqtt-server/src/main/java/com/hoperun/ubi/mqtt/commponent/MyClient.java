package com.hoperun.ubi.mqtt.commponent;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttClientPersistence;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence;

public class MyClient extends MqttClient {

	public MyClient(String serverURI, String clientId, MqttClientPersistence persistence) throws MqttException {
		super(serverURI, clientId, persistence);
		this.aClient = new MyMqttAsy(serverURI, clientId, persistence);
	}
	
	public MyClient(String serverURI, String clientId) throws MqttException {
		this(serverURI, clientId, new MqttDefaultFilePersistence());
	}
	
	public MqttTopic getTopic(String topic,boolean allow) {
		return ((MyMqttAsy)this.aClient).getTopic(topic,allow);
	}

}
